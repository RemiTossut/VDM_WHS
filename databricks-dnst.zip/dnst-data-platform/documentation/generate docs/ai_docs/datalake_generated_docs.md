# SharePoint Data Ingestion Framework Documentation

# Multi-Wholesaler Data Ingestion Framework Documentation

## 1. Framework Overview

The multi-wholesaler data ingestion framework is a standardized, reusable solution designed to handle data ingestion processes for multiple wholesalers. Each wholesaler is managed through a dedicated notebook that adheres to identical logic, ensuring consistency and scalability across the framework. This framework is **Flowbase-compliant**, meaning it integrates seamlessly with Flowbase pipelines by adhering to its metadata and output table requirements.

The primary goal of this framework is to automate the ingestion of data from SharePoint folders, process the files (e.g., converting Excel files to CSV format), and store the resulting data and metadata in a structured format within the Databricks environment. This documentation provides a comprehensive overview of the framework's functionality, data flow, and core business logic.

---

## 2. Functional Data Flow

The framework follows a standardized end-to-end data ingestion process. Below is an outline of the key steps involved:

1. **Authentication**: Establish a secure connection to the SharePoint environment using the Microsoft Graph API.
2. **File Listing**: Recursively traverse the SharePoint folder structure to identify and retrieve relevant files.
3. **File Download and Conversion**: Download the identified Excel files, convert them to CSV format, and store them in the target folder path.
4. **Metadata Table Creation**: Generate and populate a metadata table for each wholesaler. This metadata table is a critical component for **Flowbase integration**, as it serves as an output table dependency rather than a primary data output.

### Metadata Table

The metadata table is a required component for integrating the framework with Flowbase. It contains essential information about the processed files, such as file names, processing timestamps, and other relevant metadata. Below is a summary of the wholesalers, their respective target folder paths, and their metadata table paths:

| **Wholesaler Name**         | **Target Folder Path**                                                                                     | **Target Metadata Table Path**                                                                 |
|-----------------------------|-----------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| Agora Culinair Van Hout     | `/Volumes/d_dnst_000_landing/volumes/sellout_data/5525957___Agora_Culinair_Van_Hout___V0`                 | `d_dnst_000_landing.metadata.Agora_Culinair_Van_Hout_5525957_V0_metadata`                    |
| Agora Culinair VLB          | `/Volumes/d_dnst_000_landing/volumes/sellout_data/5525741___Agora_Culinair_VLB___V0/`                    | `d_dnst_000_landing.metadata.Agora_Culinair_vlb_5525741_V0_metadata`                         |

---

## 3. Core Business Logic

The framework's core business logic is divided into three main functional sections. Each section is designed to perform a specific task in the data ingestion process:

### 3.1 Authentication
The framework uses the **Microsoft Graph API** to authenticate and establish a secure connection to the SharePoint environment. This step ensures that the framework has the necessary permissions to access and retrieve files from the designated SharePoint folders.

### 3.2 File Listing
Once authenticated, the framework recursively traverses the SharePoint folder structure to identify all relevant files. This process ensures that only the required files (e.g., Excel files) are selected for further processing.

### 3.3 File Download and Conversion
The identified files are downloaded from the SharePoint folder and converted from their original Excel format to CSV format. The converted files are then stored in the specified target folder path for each wholesaler.

### 3.4 Metadata Table Creation
After processing the files, the framework generates a metadata table for each wholesaler. This table contains detailed information about the processed files, such as:
- File names
- Processing timestamps
- File sizes
- Any additional metadata required for Flowbase integration

The metadata table is written to the specified target metadata table path in the Databricks environment.

---

This documentation provides a high-level overview of the multi-wholesaler data ingestion framework, its functional data flow, and the core business logic. For further details or troubleshooting, please refer to the specific implementation guidelines or contact the framework administrator.