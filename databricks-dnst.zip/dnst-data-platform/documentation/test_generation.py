# Databricks notebook source
# MAGIC %md
# MAGIC # 📥 Download and Stage Excel Files from SharePoint
# MAGIC
# MAGIC This notebook is designed to download Excel files from a specified SharePoint folder, convert them to CSV format, and write the resulting files to a designated landing area. Additionally, it captures metadata about the processed files for further analysis.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## ⚙️ Configuration/Parameters
# MAGIC
# MAGIC - **target_catalog**: `d_dnst_000_landing`  
# MAGIC   The catalog where metadata will be written.
# MAGIC - **target_schema**: `metadata`  
# MAGIC   The schema for the metadata table.
# MAGIC - **target_table**: `Agora_Culinair_Van_Hout_5525957_V0_metadata`  
# MAGIC   The name of the metadata table.
# MAGIC - **landing_root**: `/Volumes/d_dnst_000_landing/volumes/sellout_data/5525957___Agora_Culinair_Van_Hout___V0`  
# MAGIC   The root directory for landing files.
# MAGIC - **sharepoint_folder**: `Collection sell-out data/5525957 - Agora Culinair Van Hout - V0`  
# MAGIC   The SharePoint folder containing the files.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📄 Logical Steps
# MAGIC
# MAGIC 1. **Authentication**:  
# MAGIC    Retrieve an access token to authenticate with the SharePoint API using client credentials.
# MAGIC
# MAGIC 2. **Get Site & Drive IDs**:  
# MAGIC    Fetch the site and drive IDs necessary for accessing files in SharePoint.
# MAGIC
# MAGIC 3. **List Files Recursively**:  
# MAGIC    Recursively list all files in the specified SharePoint folder while skipping any folders defined in the configuration.
# MAGIC
# MAGIC 4. **Download, Convert to CSV, Write to Landing**:  
# MAGIC    For each file, download it, convert the relevant sheets to CSV format, and save them to the landing directory. Collect metadata for each processed file.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 🔍 Technical Details
# MAGIC
# MAGIC ### Authentication Function
# MAGIC
# MAGIC ```python
# MAGIC def get_token():
# MAGIC     url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
# MAGIC     data = {
# MAGIC         "grant_type": "client_credentials",
# MAGIC         "client_id": client_id,
# MAGIC         "client_secret": client_secret,
# MAGIC         "scope": "https://graph.microsoft.com/.default"
# MAGIC     }
# MAGIC     r = requests.post(url, data=data)
# MAGIC     r.raise_for_status()
# MAGIC     return r.json()["access_token"]
# MAGIC ```
# MAGIC
# MAGIC ### List Files Function
# MAGIC
# MAGIC ```python
# MAGIC def list_files(folder_path):
# MAGIC     enc = urllib.parse.quote(folder_path, safe="")
# MAGIC     url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/root:/{enc}:/children"
# MAGIC     r = requests.get(url, headers=headers)
# MAGIC     r.raise_for_status()
# MAGIC     items = r.json()["value"]
# MAGIC     files = []
# MAGIC     for it in items:
# MAGIC         name = it.get("name")
# MAGIC         path = f"{folder_path}/{name}"
# MAGIC         if "file" in it and fnmatch.fnmatch(name, config["file_pattern"]):
# MAGIC             files.append(path)
# MAGIC         elif "folder" in it:
# MAGIC             if any(skip.lower() in name.lower() for skip in config["folder_name_skip"]):
# MAGIC                 print(f"⏩ Skipping folder: {name}")
# MAGIC                 continue
# MAGIC             files.extend(list_files(path))
# MAGIC     return files
# MAGIC ```
# MAGIC
# MAGIC ### Download and Stage Function
# MAGIC
# MAGIC ```python
# MAGIC def download_and_stage_excel_files():
# MAGIC     files_to_download = list_files(sharepoint_folder)
# MAGIC     metadata_rows = []
# MAGIC     run_start_time = time.strftime("%Y-%m-%d %H:%M:%S")  # Common timestamp for all rows
# MAGIC
# MAGIC     for sp_path in files_to_download:
# MAGIC         try:
# MAGIC             enc = urllib.parse.quote(sp_path, safe="")
# MAGIC             url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/root:/{enc}:/content"
# MAGIC             r = requests.get(url, headers=headers, stream=True)
# MAGIC             r.raise_for_status()
# MAGIC
# MAGIC             buf = BytesIO(r.content)
# MAGIC             xls = pd.ExcelFile(buf)
# MAGIC             filename_base = os.path.splitext(os.path.basename(sp_path))[0].replace(" ", "_").replace("-", "_")
# MAGIC
# MAGIC             if config["sheet_name"]:
# MAGIC                 sheets_to_process = [config["sheet_name"]] if config["sheet_name"] in xls.sheet_names else []
# MAGIC             else:
# MAGIC                 sheets_to_process = [s for s in xls.sheet_names if s not in (config["sheet_name_skip"] or [])]
# MAGIC
# MAGIC             for sheet in sheets_to_process:
# MAGIC                 df = pd.read_excel(xls, sheet_name=sheet)
# MAGIC                 out_filename = f"{filename_base}_{sheet}.csv"
# MAGIC                 relative_path = os.path.dirname(sp_path.replace(sharepoint_folder, "").lstrip("/"))
# MAGIC                 out_dir = f"{landing_root}/{relative_path}"
# MAGIC                 dbutils.fs.mkdirs(out_dir)
# MAGIC                 out_path = f"{out_dir}/{out_filename}"
# MAGIC
# MAGIC                 csv_data = df.to_csv(index=False)
# MAGIC                 dbutils.fs.put(out_path, csv_data, overwrite=True)
# MAGIC
# MAGIC                 metadata_rows.append(Row(
# MAGIC                     source_path=sp_path,
# MAGIC                     sheet_name=sheet,
# MAGIC                     output_path=out_path,
# MAGIC                     row_count=len(df),
# MAGIC                     column_count=len(df.columns),
# MAGIC                     timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
# MAGIC                     runstarttime=run_start_time
# MAGIC                 ))
# MAGIC
# MAGIC                 print(f"✅ Saved {out_path}")
# MAGIC
# MAGIC         except Exception as e:
# MAGIC             print(f"❌ Error processing {sp_path}: {e}")
# MAGIC
# MAGIC     df_metadata = spark.createDataFrame(metadata_rows)
# MAGIC
# MAGIC     df_metadata = (
# MAGIC         df_metadata
# MAGIC         .withColumn("row_count", F.col("row_count").cast(IntegerType()))
# MAGIC         .withColumn("column_count", F.col("column_count").cast(IntegerType()))
# MAGIC         .withColumn("timestamp", F.to_timestamp("timestamp"))
# MAGIC         .withColumn("runstarttime", F.to_timestamp("runstarttime"))
# MAGIC     )
# MAGIC     return df_metadata
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Execution
# MAGIC
# MAGIC To execute the download and staging process, call the function:
# MAGIC
# MAGIC ```python
# MAGIC fn_flowbase = download_and_stage_excel_files
# MAGIC ```
# MAGIC
# MAGIC This will initiate the process of downloading Excel files, converting them to CSV, and saving the metadata.
