# Databricks notebook source
# Set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging

# COMMAND ----------

run_id = Logging.start_run(main_process='maintenance', parameters={})

# COMMAND ----------

pipeline_maintenance = Pipeline().load()

# COMMAND ----------

pipeline_maintenance.orchestrate_dag_via_dependencies(method_operation='do_nothing',method_data_asset='optimize', worker_amount = 2)

# COMMAND ----------

pipeline_maintenance.visualize()

# COMMAND ----------

pipeline_maintenance.orchestrate_dag_via_dependencies(method_operation='do_nothing',method_data_asset='vacuum', worker_amount = 2)

# COMMAND ----------

pipeline_maintenance.visualize()

# COMMAND ----------

Logging.end_run()
