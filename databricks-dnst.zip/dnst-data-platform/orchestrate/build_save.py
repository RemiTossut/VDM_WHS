# Databricks notebook source
# Set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging

# COMMAND ----------

run_id = Logging.start_run(main_process='build', parameters={})

# COMMAND ----------

pipeline_build = Pipeline()
pipeline_build.build()

# COMMAND ----------

pipeline_build.visualize()

# COMMAND ----------

pipeline_build.save()

# COMMAND ----------

Logging.end_run()
