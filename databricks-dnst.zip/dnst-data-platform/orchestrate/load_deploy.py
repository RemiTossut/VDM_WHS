# Databricks notebook source
# Set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging

# COMMAND ----------

run_id = Logging.start_run(main_process='deploy', parameters={})

# COMMAND ----------

pipeline_deploy = Pipeline().load()

# COMMAND ----------

pipeline_deploy.deploy()

# COMMAND ----------

pipeline_deploy.visualize()

# COMMAND ----------

Logging.end_run()
