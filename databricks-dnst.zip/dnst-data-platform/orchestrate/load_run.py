# Databricks notebook source
# set widgets (required to pass job parameters)
dbutils.widgets.text('sources_to_load', '[]')

# COMMAND ----------

# set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging
from flowbase.toolkit.flowbase_globals import flowbase_globals
import json

# COMMAND ----------

# set global constants
flowbase_globals.set_constant('sources_to_load', json.loads(dbutils.widgets.get('sources_to_load')))

# COMMAND ----------

run_id = Logging.start_run(main_process='run', parameters={})

# COMMAND ----------

pipeline_run = Pipeline().load().get_sub_pipeline(flowbase_globals.get_constant('sources_to_load'), ancestors=False, descendants=True)

# COMMAND ----------

pipeline_run.run(worker_amount=2, screenings=True)

# COMMAND ----------

pipeline_run.visualize()

# COMMAND ----------

Logging.end_run()
