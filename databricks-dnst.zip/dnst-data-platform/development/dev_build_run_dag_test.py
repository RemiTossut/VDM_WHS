# Databricks notebook source
# Set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging, get_service_connector

# COMMAND ----------

# start logging
run_id = Logging.start_run(main_process='development', parameters={})
print(run_id)

# COMMAND ----------

from commenting_module import get_add_comment_hook_code

# COMMAND ----------

# create empty pipeline
pipeline_dev = Pipeline()

# build pipeline only subset
pipeline_dev.build(filters=[
    # "V2_02_prepare_sellout_consolidated",
    # "01_prepare_sellout_consolidated",
    # "(Clone) 02_prepare_sellout_consolidated",
    # "ilis_5526147_v0",
    # "034_prepare_sel_out_customers_int_matched",
    # "01_prepare_sellout_customers_ext_matched"
    # "v_sellout"
    # "knmt_dumps_raw",
    # "uom"
],raise_error= True) # Regex of notebook path
# pipeline_dev.build() # Regex of notebook path

# COMMAND ----------

# change table structure if necessary
pipeline_dev.deploy()

# COMMAND ----------

pipeline_dev.print_dag()

# COMMAND ----------

pipeline_dev.visualize(live_updates=False)

# COMMAND ----------

# materialize
# pipeline_dev.run()

# COMMAND ----------

# end logging
# Logging.end_run()
