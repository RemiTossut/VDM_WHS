# Databricks notebook source
# Set environment specific config
import os
from dbruntime.databricks_repl_context import get_context
os.environ['FLOWBASE_CONFIG'] = f"../configuration/flowbase_config_{get_context().workspaceId}.json"

# COMMAND ----------

# MAGIC %run ../modules/load_modules

# COMMAND ----------

from flowbase.framework import Pipeline, Logging, get_service_connector

# COMMAND ----------

# start logging
run_id = Logging.start_run(main_process='development', parameters={})
print(run_id)

# COMMAND ----------

# create empty pipeline
nodes_to_load = ["01_sellout_consolidated"]
pipeline_dev = Pipeline().load().get_sub_pipeline(nodes_to_load)

# # build pipeline only subset
# pipeline_dev.build(filters=[]) # Regex of notebook path
# # pipeline_dev.build() # Regex of notebook path

# COMMAND ----------

# create empty pipeline
pipeline_dev = Pipeline()

# build pipeline only subset
pipeline_dev.build(filters=[
    '01_prepare_sellout_consolidated'
]) # Regex of notebook path
# pipeline_dev.build() # Regex of notebook path

# COMMAND ----------

# change table structure if necessary
pipeline_dev.deploy()

# COMMAND ----------

pipeline_dev.visualize(live_updates=False)

# COMMAND ----------

# materialize
pipeline_dev.run()

# COMMAND ----------

# end logging
Logging.end_run()

# COMMAND ----------


