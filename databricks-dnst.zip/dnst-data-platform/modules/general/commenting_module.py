
def get_add_comment_hook_code(target_catalog: str, target_schema: str, target_table: str, column_metadata: list) -> str:
    """
    Generates hook code that strips out single quotes and newlines
    to ensure zero SQL syntax errors.
    """
    python_code = f"""
# Dynamically set the full table name
full_table_name = '`{target_catalog}`.`{target_schema}`.`{target_table}`'

# Metadata list
COLUMN_METADATA = {column_metadata} 

for col_info in COLUMN_METADATA:
    col_name = col_info['col']
    col_type = col_info['type']
    
    # Replace single quotes with a space and remove newlines
    # This guarantees no [PARSE_SYNTAX_ERROR]
    clean_comment = col_info['comment'].replace("'", " ").replace("\\n", " ").replace("\\r", " ")
    
    sql_statement = f'''
        ALTER TABLE {{full_table_name}}
        CHANGE COLUMN `{{col_name}}` `{{col_name}}` {{col_type}}
        COMMENT '{{clean_comment}}'
    '''
    
    spark.sql(sql_statement)
"""
    return python_code

# def get_add_table_description_hook_code(target_catalog: str, target_schema: str, target_table: str, table_description: str) -> str:
#     """
#     Generates the Python code string to be executed as a Flowbase hook
#     to apply a table-level comment via ALTER TABLE.

#     Args:
#         target_catalog (str): The Unity Catalog name.
#         target_schema (str): The schema name.
#         target_table (str): The table name.
#         table_description (str): The description text for the table.

#     Returns:
#         str: The complete Python code string for the hook's 'code' field.
#     """

#     # Escape quotes for the description to prevent SQL injection/syntax errors
#     escaped_description = table_description.replace("'", "''")

#     python_code = f"""
# # Dynamically set the full table name
# full_table_name = '`{target_catalog}`.`{target_schema}`.`{target_table}`'
# table_comment = '{escaped_description}'

# # SQL statement to update the table-level comment
# sql_statement = f"COMMENT ON TABLE {{full_table_name}} IS '{{table_comment}}'"

# # Execute the DDL statement
# spark.sql(sql_statement)
# """
#     return python_code

def get_add_table_description_hook_code(target_catalog: str, target_schema: str, target_table: str, table_description: str) -> str:
    """
    Generates a Flowbase hook to apply a Markdown table comment.
    Fixes the SyntaxError by escaping newlines and removing single quotes.
    """

    # 1. Replace single quotes with spaces (the "Safe" strategy)
    # 2. Escape actual newlines so the generated code is a single line
    safe_description = table_description.replace("'", " ").replace("\n", "\\n")

    python_code = f"""
# Variables set via generator
full_table_name = '`{target_catalog}`.`{target_schema}`.`{target_table}`'
table_comment = '{safe_description}'

# Apply comment; Unity Catalog will render the \\n as Markdown line breaks
spark.sql(f"COMMENT ON TABLE {{full_table_name}} IS '{{table_comment}}'")
"""
    return python_code
