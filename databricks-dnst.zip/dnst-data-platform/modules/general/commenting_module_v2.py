def get_add_comment_hook_code(target_catalog: str, target_schema: str, target_table: str, column_metadata: list) -> str:
    """
    Generates the Python code string that will be executed as a Flowbase hook
    to apply multiple column comments efficiently using a single ALTER TABLE statement.

    Args:
        target_catalog (str): The Unity Catalog name.
        target_schema (str): The schema name.
        target_table (str): The table name.
        column_metadata (list): List of dictionaries containing column name, type, and comment.

    Returns:
        str: The complete Python code string for the hook's 'code' field.
    """

    python_code = f"""
from typing import List, Dict, Any

# Dynamically set the full table name
full_table_name = '`{target_catalog}`.`{target_schema}`.`{target_table}`'

# This Python list holds your metadata inside the hook code itself
COLUMN_METADATA: List[Dict[str, Any]] = {column_metadata} 
COMMENT_CLAUSES = []

# Build the list of COMMENT clauses for the single DDL statement.
# We no longer need the column type ('col_type') for this optimized syntax.
for col_info in COLUMN_METADATA:
    col_name = col_info['col']
    
    # Escape quotes for the SQL statement: ' -> ''
    # This ensures apostrophes like in "operator's" are handled correctly by Spark SQL.
    escaped_comment = col_info['comment'].replace("'", "''") 
    
    # Format the clause using the optimized multi-column ALTER COLUMN syntax:
    # ALTER COLUMN <col_name> COMMENT '<comment>'
    clause = f"\\n   `{{col_name}}` COMMENT '{{escaped_comment}}'"
    COMMENT_CLAUSES.append(clause)

# Join all individual clauses with a comma separator (and a newline for readability)
clauses_str = ",".join(COMMENT_CLAUSES)
    
sql_statement = f'''
    -- Optimized DDL: Using the multi-column ALTER COLUMN syntax for efficiency
    ALTER TABLE {{full_table_name}} 
    ALTER COLUMN
    {{clauses_str}}
'''

# Execute the single, optimized DDL statement
spark.sql(sql_statement)
"""
    return python_code

