# number of api calls that can be made per month:
api_calls_limit = 40


from imports import *

def get_sellout_api_config(api_key):
    api_config = {
        "addressvalidation": {
            "api_name": "addressvalidation",
            "url": f"https://addressvalidation.googleapis.com/v1:validateAddress?key={api_key}",
            "payload": {
                "address": {
                    "regionCode": "customer_country",
                    "addressLines": ["customer_address", "customer_name"],
                    "locality": "customer_city",
                    "postalCode": "customer_postal_code"
                }
            }
        }
    }

    return api_config

def get_c4s_api_config(api_key):
    api_config = {
        "addressvalidation": {
            "api_name": "addressvalidation",
            "url": f"https://addressvalidation.googleapis.com/v1:validateAddress?key={api_key}",
            "payload": {
                "address": {
                    "regionCode": "c4cu_country_id",
                    "addressLines": ["addressLines"]
                }
            }
        }
    }

    return api_config

def call_google_api(url, payload):
    try:
        # Normalize payload to a Python dict
        if isinstance(payload, Row):
            payload = payload.asDict(recursive=True)
        elif isinstance(payload, str):
            payload = json.loads(payload)  # in case you passed JSON string
        elif not isinstance(payload, dict):
            # Fallback: wrap unknown type
            payload = {} if payload is None else {"payload": payload}

        # Make the request
        response = requests.post(url, json=payload, timeout=20)
        response.raise_for_status()

        return json.dumps(response.json(), ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)

call_google_api_udf = udf(call_google_api, T.StringType())


def _expr_from_spec(spec, df):
    """
    Recursively build a Column expression from a Python literal spec.

    Rules:
    - dict  -> struct of its fields
    - list/tuple -> array of elements
    - str   -> if matches a df column name, use that column; otherwise literal string
    - other -> literal (number, bool, None, etc.)
    """
    if isinstance(spec, dict):
        fields = [ _expr_from_spec(v, df).alias(k) for k, v in spec.items() ]
        return F.struct(*fields)
    elif isinstance(spec, (list, tuple)):
        elems = [ _expr_from_spec(x, df) for x in spec ]
        return F.array(*elems)
    elif isinstance(spec, str):
        return F.col(spec) if spec in df.columns else F.lit(spec)
    else:
        return F.lit(spec)

def build_payload_col(df, api_config: dict, endpoint: str, as_json: bool = False):
    """
    Build a Column for the API payload from the nested config.

    If as_json=False (default): returns a STRUCT column suitable for passing directly to a UDF.
    If as_json=True: returns a JSON string column (via to_json).
    """
    payload_spec = api_config[endpoint]["payload"]
    col_expr = _expr_from_spec(payload_spec, df)
    return F.to_json(col_expr) if as_json else col_expr

def add_payload_to_df(df, api_name, api_key, payload_type):
    if payload_type == "c4s":
        api_config = get_c4s_api_config(api_key)
    elif payload_type == "sellout":
        api_config = get_sellout_api_config(api_key)
    url_str = api_config[api_name]["url"]
    payload_col = build_payload_col(df, api_config, api_name)
    df_with_addressvalidation_payload = (
        df
        .withColumn("payload", payload_col)
        .withColumn("api_url", F.lit(url_str))
        .withColumn(
                "payload_string", F.to_json(F.col("payload"))
        )
        .withColumn("api_name", F.lit(api_name))
    )
    return df_with_addressvalidation_payload

def fetch_existing_mappings(df,df_existing_mappings, api_name):

    df_with_existing_mappings = (
        df.alias("b")
        .join(
            df_existing_mappings.alias("t"),
            F.expr("b.payload_string = t.payload and b.api_name = t.api_name"),
            how="left"
        )
        .selectExpr(
            "b.*",
            "t.browser_url",
            "t.place_id",
            "t.google_api_raw_json"
        )
    )
    
    window_spec = Window.partitionBy("payload_string", "api_name").orderBy(F.lit(1))

    df_deduped = (
        df_with_existing_mappings.withColumn("row_num", F.row_number().over(window_spec))
        .filter(F.col("row_num") == 1)
        .drop("row_num")
    )

    return df_with_existing_mappings

def apply_google_api(df, api_name):
    
    df_result = (
        df
        .withColumn(
        "google_api_raw_json",
        call_google_api_udf(
            df["api_url"], 
            df["payload"], 
        )
        )
        .withColumn(
            "Place_ID",
            F.when(
                (F.get_json_object("google_api_raw_json", "$.result.geocode.featureSizeMeters").cast("float") < 100) &
                (F.get_json_object("google_api_raw_json", "$.result.verdict.geocodeGranularity") != "OTHER"),
                F.get_json_object("google_api_raw_json", "$.result.geocode.placeId")
            ).otherwise(None)
        )
        .withColumn(
            "browser_url",
            F.when(
                F.col("place_id").isNotNull() & (F.col("place_id") != ""),
                F.concat(
                    F.lit("https://www.google.com/maps/search/?q=place_id:"),
                    F.col("place_id")
                )
            ).otherwise(F.lit(None))
        )
        
        .withColumn(
            "api_url_masked",
            F.regexp_replace(
                F.col("api_url"),
                r"(key=)[^&]+",   # match 'key=' followed by any characters until '&' or end
                r"\***"          # keep 'key=' and replace the rest with ***
            )
        )

        .withColumn(
            "api_execution_timestamp",
            F.current_timestamp()
        )
        
    )
    return df_result


