# from imports import *
# ---------------------
# REQUIRED IMPORTS
# ---------------------

import warnings
warnings.filterwarnings("ignore", ".*sql_ctx is an internal property.*", UserWarning)

# PySpark
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import Window

# Typing
from typing import Dict, Callable, List, Mapping, Optional

# Standard library
import json
from pyspark.sql import DataFrame, Column
from typing import List, Mapping, Optional, Callable, Dict
import pyspark.sql.functions as F
from pyspark.sql import Window


# Suppress the PySpark UserWarning that is triggered by GraphFrames' internal use of sql_ctx.
# We ignore this because the warning is in a third-party library, not our code.
warnings.filterwarnings("ignore", ".*sql_ctx is an internal property.*", UserWarning)

# matching_functions.py
# Utilities to apply exact and fuzzy (Levenshtein) matching rules and assign unified IDs.
# Designed for PySpark; no actions are triggered inside these functions.
# ---------------------------
# Matcher registry & utilities
# ---------------------------

_MATCHERS: Dict[str, Callable[..., DataFrame]] = {}


def register_matcher(name: str):
    """
    Decorator to register a matcher function under a name.

    Each matcher must have signature:
        fn(source: DataFrame, target: DataFrame, *, rule: Mapping, target_id_column: str, ...) -> DataFrame
    and return the *source* DataFrame with a new column (rule['result_column']) added.
    """
    def _decorator(func: Callable[..., DataFrame]):
        _MATCHERS[name] = func
        return func
    return _decorator


def apply_matching(
    *,
    source: DataFrame,
    target: DataFrame,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True,
    match_rules: List[Mapping]
) -> DataFrame:
    """
    Applies match rules in order. For each rule, looks up the matcher by rule['match_type']
    and lets it add rule['result_column'] to the evolving DataFrame.

    If id_matching_allowed is False, matchers will avoid matching rows where source_id == target_id.
    """
    df = source
    for rule in match_rules:
        mtype = rule.get("match_type")
        if not mtype:
            raise ValueError(f"Rule missing 'match_type': {rule}")
        matcher = _MATCHERS.get(mtype)
        if matcher is None:
            raise ValueError(f"No matcher registered for type '{mtype}'. Registered: {list(_MATCHERS)}")

        df = matcher(
            df,
            target,
            rule=rule,
            target_id_column=target_id_column,
            source_id_column=source_id_column,
            id_matching_allowed=id_matching_allowed
        )
    return df


# ---------------------------
# EXACT matcher (symmetric)
# ---------------------------
from pyspark.sql import DataFrame, Column, Window
from pyspark.sql import functions as F
from typing import Mapping, List, Optional
# Assuming @register_matcher is defined elsewhere

@register_matcher("exact")
def exact_match(
    source: DataFrame,
    target: DataFrame,
    *,
    rule: Mapping,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True
) -> DataFrame:
    """
    Left-join source to target on ALL specified column equalities (exact match).
    Refactored to use the stable key and column processing logic from levenstein_match.
    """
    
    column_pairs: List[Mapping] = rule.get("columns", [])
    if not column_pairs:
        raise ValueError("Exact match rule requires a 'columns' list for multi-column matching.")
        
    out_col = rule["result_column"]
    
    # Normalizer helper
    def normalize_expr(col_expr, spec):
        # 1. Explicitly cast to string for pipeline consistency (CRITICAL FIX)
        col_expr = col_expr.cast("string") 
        
        if spec.get("trim_spaces_before_and_after", False):
            col_expr = F.trim(col_expr)
        if spec.get("make_case_insensitive", False):
            col_expr = F.upper(col_expr) # Normalize to upper case for comparison
        return col_expr

    # --- 1. Prepare Source (Left) DF ---
    src = source
    source_cols_in_order = source.columns
    temp_cols_to_drop = []

    # Prepare stable ID and source ID
    if source_id_column:
        src = src.withColumn("_m_src_id", F.col(source_id_column).cast("string"))
        temp_cols_to_drop.append("_m_src_id")
        # Build a deterministic row key from the business id
        src = src.withColumn("_m_src_key", F.col("_m_src_id"))
    
    # Normalized columns for comparisons
    normalized_src_cols = []
    for i, pair in enumerate(column_pairs):
        alias = f"_m_src_{i}"
        src_col = pair["source_column"]
        src = src.withColumn(alias, normalize_expr(F.col(src_col), pair))
        normalized_src_cols.append(F.col(alias))
        temp_cols_to_drop.append(alias)
        
    # If source_id_column is absent, build a stable hash-based key
    if not source_id_column:
        src = src.withColumn(
            "_m_src_key",
            F.sha2(F.concat_ws("|", *normalized_src_cols), 256)
        )
    temp_cols_to_drop.append("_m_src_key")

    # --- 2. Prepare Target (Right) DF ---
    tgt_selects = [F.col(target_id_column).cast("string").alias("_m_tgt_id")]
    
    # Normalized columns for comparisons
    normalized_tgt_cols = []
    for i, pair in enumerate(column_pairs):
        alias = f"_m_tgt_{i}"
        tgt_col = pair["target_column"]
        tgt_selects.append(normalize_expr(F.col(tgt_col), pair).alias(alias))
        normalized_tgt_cols.append(F.col(alias))
        temp_cols_to_drop.append(alias)

    tgt = target.select(*tgt_selects)

    # --- 3. Build Compound Join Condition (Exact Match) ---
    join_expr = None
    for i in range(len(column_pairs)):
        src_col_alias = f"_m_src_{i}"
        tgt_col_alias = f"_m_tgt_{i}"

        # Condition requires both source and target key to be NOT NULL AND equal
        cond_i = (
            F.col(src_col_alias).isNotNull()
            & F.col(tgt_col_alias).isNotNull()
            & (F.col(src_col_alias) == F.col(tgt_col_alias))
        )
        join_expr = cond_i if join_expr is None else (join_expr & cond_i)

    if join_expr is None:
        raise ValueError("Join condition is empty. Ensure 'columns' list is not empty.")
        
    # --- 4. Perform Join and Filter ---
    # Perform a LEFT join since we want all source rows
    joined = src.alias("s").join(tgt.alias("t"), on=join_expr, how="left")
    
    # Select non-ambiguous columns for the next step, retaining the source keys
    candidates = joined.select(
        *[F.col(f"s.{c}") for c in src.columns],
        F.col("t._m_tgt_id").alias("_m_id") # Use generic _m_id alias for match result
    )

    # Exclude null candidates and (optionally) self-match
    if not id_matching_allowed and source_id_column:
        candidates = candidates.where(F.col("_m_id").isNotNull() & (F.col("_m_id") != F.col("_m_src_id")))
    else:
        candidates = candidates.where(F.col("_m_id").isNotNull())

    # --- 5. Pick Best Candidate (Tie-breaker) ---
    # Partition by the stable source key and order by target ID (deterministic tie-breaker)
    w = Window.partitionBy("_m_src_key").orderBy(F.col("_m_id").asc())
    
    picked = (
        candidates
        .withColumn("_m_rn", F.row_number().over(w))
        .where(F.col("_m_rn") == 1)
        .select(
            F.col("_m_src_key"), 
            F.col("_m_id").alias(out_col)
        )
    )
    temp_cols_to_drop.append("_m_rn")

    # --- 6. Final Join and Projection ---
    final = src.join(picked, on="_m_src_key", how="left")
    
    # Explicit final projection to ensure original column order and drop all temporary columns
    final_cols = [c for c in source_cols_in_order]
    
    # Add the result column if it doesn't already exist (it should only exist from the match)
    final_cols.append(out_col)
    
    final = final.select(final_cols)
    
    # The selection above implicitly handles column dropping, but we return the full list 
    # for completeness, although dropping may be redundant after explicit select.
    # return final.drop(*temp_cols_to_drop)
    return final
# ---------------------------
# LEVENSHTEIN (weighted fuzzy)
# ---------------------------
@register_matcher("levenstein")
def levenstein_match(
    source: DataFrame,
    target: DataFrame,
    *,
    rule: Mapping,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True,
) -> DataFrame:
    """
    Levenstein (weighted fuzzy) matcher.

    It performs a join based on all 'exact' columns first, then calculates
    a weighted Levenshtein score on 'fuzzy' columns.
    """
    columns: List[Mapping] = rule["columns"]
    out_col = rule["result_column"]
    score_col = rule.get("score_column", "levenstein_score")
    details_col = rule.get("comparison_details_column", "match_details")
    # value_dict_col is optional for backward compatibility but included if present
    value_dict_col = rule.get("value_dict_column", "value_dict")
    min_score = float(rule.get("min_score", 0.0))

    # Split columns into exact and fuzzy categories
    exact_cols = [c for c in columns if c.get("match") == "exact"]
    fuzzy_cols = [c for c in columns if c.get("match") != "exact"]

    # Must have at least one exact column to constrain the search space
    if not exact_cols:
        raise ValueError("levenstein matcher requires at least one column with match='exact'")

    # Normalizer helper
    def normalize_expr(col_expr, spec):
        if spec.get("trim_spaces_before_and_after", False):
            col_expr = F.trim(col_expr)
        if spec.get("make_case_insensitive", False):
            col_expr = F.upper(col_expr)
        return col_expr

    # Prepare source DF: stable ID and normalized comparison columns
    # --- CHANGE 1: Prefer a stable business key over monotonically_increasing_id ---
    src = source
    temp_cols_to_drop = []

    # Keep the original source column names and order for final projection
    source_cols_in_order = source.columns  # <-- used later for explicit projection

    if source_id_column:
        src = src.withColumn("_m_src_id", F.col(source_id_column).cast("string"))
        temp_cols_to_drop.append("_m_src_id")
        # Build a deterministic row key from the business id
        src = src.withColumn("_m_src_key", F.col("_m_src_id"))
    else:
        # If no business id was provided, build a deterministic hash
        # of all normalized comparison columns (robust fallback)
        # We'll populate the normalized cols first and then hash them.
        pass

    # Normalized columns for comparisons
    for i, spec in enumerate(columns):
        alias = f"_m_src_{i}"
        src = src.withColumn(alias, normalize_expr(F.col(spec["source_column"]), spec))
        temp_cols_to_drop.append(alias)

    # If source_id_column is absent, now build a stable hash-based key
    if not source_id_column:
        src = src.withColumn(
            "_m_src_key",
            F.sha2(F.concat_ws("|", *[F.col(f"_m_src_{i}") for i in range(len(columns))]), 256)
        )
    temp_cols_to_drop.append("_m_src_key")

    # Prepare target DF: Target ID and normalized comparison columns
    tgt_selects = [F.col(target_id_column).cast("string").alias("_m_tgt_id")]
    for i, spec in enumerate(columns):
        alias = f"_m_tgt_{i}"
        tgt_selects.append(normalize_expr(F.col(spec["target_column"]), spec).alias(alias))
        temp_cols_to_drop.append(alias)

    tgt = target.select(*tgt_selects).dropDuplicates()

    # Build exact-match condition on all exact columns
    join_expr = None
    for c in exact_cols:
        i = columns.index(c)
        src_col_alias = f"_m_src_{i}"
        tgt_col_alias = f"_m_tgt_{i}"

        # Condition requires both source and target key to be NOT NULL AND equal
        cond_i = (
            F.col(src_col_alias).isNotNull()
            & F.col(tgt_col_alias).isNotNull()
            & (F.col(src_col_alias) == F.col(tgt_col_alias))
        )
        join_expr = cond_i if join_expr is None else (join_expr & cond_i)

    # Inner join only candidates that match exact columns (pre-condition)
    candidates = src.join(tgt, on=join_expr, how="inner")

    # --- Enforce Self-Match Exclusion (Crucial Fix) ---
    if (not id_matching_allowed) and source_id_column:
        candidates = candidates.where(F.col("_m_tgt_id") != F.col("_m_src_id"))

    # Handle case where no candidates remain after filtering
    if candidates.rdd.isEmpty():
        out_null = (
            src.withColumn(out_col, F.lit(None))
               .withColumn(score_col, F.lit(None))
               .withColumn(details_col, F.lit(None))
        )
        if value_dict_col:
            out_null = out_null.withColumn(value_dict_col, F.lit(None))

        # --- CHANGE 2: Explicit final projection of source columns + match columns ---
        out_null = out_null.select(
            *[F.col(c) for c in source_cols_in_order],
            F.col(out_col),
            F.col(score_col),
            F.col(details_col),
            *( [F.col(value_dict_col)] if value_dict_col else [] )
        )
        return out_null  # temp cols are not present in the explicit projection

    # Compute similarity for fuzzy columns
    df = candidates
    detail_structs = []
    score_terms = []

    # Calculate scores and build match details structure
    for i, spec in enumerate(columns):
        src_col_alias = f"_m_src_{i}"
        tgt_col_alias = f"_m_tgt_{i}"

        if spec.get("match") == "exact":
            # For exact matches, similarity is 1.0 and is included in details
            detail_structs.append(
                F.struct(
                    F.lit(spec["source_column"]).alias("column"),
                    F.lit(1.0).alias("similarity"),
                    F.col(src_col_alias).alias("source_value"),
                    F.col(tgt_col_alias).alias("target_value"),
                    F.lit("exact").alias("match_type"),
                )
            )
        else:
            # For fuzzy matches, calculate Levenshtein similarity
            weight = float(spec.get("weight", 1.0))
            dist_col = F.levenshtein(F.col(src_col_alias), F.col(tgt_col_alias))
            max_len = F.greatest(F.length(F.col(src_col_alias)), F.length(F.col(tgt_col_alias)))

            # Levenshtein similarity = 1 - (distance / max_length)
            sim_col = F.when(max_len == 0, 1.0).otherwise(
                1.0 - dist_col.cast("double") / max_len.cast("double")
            )
            sim_alias = f"_m_sim_{i}"
            df = df.withColumn(sim_alias, sim_col)
            score_terms.append(F.col(sim_alias) * F.lit(weight))
            temp_cols_to_drop.append(sim_alias)  # Add similarity alias to drop list

            detail_structs.append(
                F.struct(
                    F.lit(spec["source_column"]).alias("column"),
                    F.col(sim_alias).alias("similarity"),
                    F.col(src_col_alias).alias("source_value"),
                    F.col(tgt_col_alias).alias("target_value"),
                    F.lit("fuzzy").alias("match_type"),
                )
            )

    # Compute final weighted average score
    if score_terms:
        total_weight = sum(float(c.get("weight", 1.0)) for c in fuzzy_cols) or 1.0
        df = df.withColumn(score_col, sum(score_terms) / F.lit(total_weight))
    else:
        # If only exact columns are specified, score is 1.0
        df = df.withColumn(score_col, F.lit(1.0))

    # Apply min_score filter
    df = df.where(F.col(score_col) >= F.lit(min_score))

    # Build details array
    details_array = F.array(*detail_structs)
    df = df.withColumn(details_col, F.to_json(details_array))

    # Build value_dict structure for result column
    value_dict_struct = F.struct(
        F.col("_m_tgt_id").alias("target_id"),
        F.col(score_col).alias("score"),
        details_array.alias("columns_compared"),
    )
    if value_dict_col:
        df = df.withColumn(value_dict_col, F.to_json(value_dict_struct))

    # Pick best candidate per source row
    # --- CHANGE 3: Use the stable key (_m_src_key) for partitioning ---
    w = Window.partitionBy("_m_src_key").orderBy(F.col(score_col).desc(), F.col("_m_tgt_id").asc())

    picked = (
        df.withColumn("_m_rn", F.row_number().over(w))
          .where(F.col("_m_rn") == 1)
          .select(
              F.col("_m_src_key"),
              F.col("_m_tgt_id").alias(out_col),
              F.col(score_col),
              F.col(details_col),
              *( [F.col(value_dict_col)] if value_dict_col else [] )
          )
    )

    # Join back to original source using the stable key
    final = src.join(picked, on="_m_src_key", how="left")

    # --- CHANGE 4: Explicit final projection of source columns + match columns ---
    final = final.select(
        *[F.col(c) for c in source_cols_in_order],
        F.col(out_col),
        F.col(score_col),
        F.col(details_col),
        *( [F.col(value_dict_col)] if value_dict_col else [] )
    )

    return final
# ---------------------------------
# Assign unified (component) ID label
# ---------------------------------

def _gather_edges(df: DataFrame, id_column: str, match_columns: List[str]) -> DataFrame:
    """
    Gathers all valid (src, dst) edges from the id_column to all match_columns.
    Returns edges as two columns: a, b (strings), with a != b, distinct.
    """
    
    # 1. Create a list of edge DataFrames
    edges_list = []
    
    for col in match_columns:
        if col in df.columns:
            e = (
                df.select(
                    F.col(id_column).cast("string").alias("a"),
                    F.col(col).cast("string").alias("b")
                )
                # Ensure neither ID is null and they are not matching themselves
                .where(F.col("a").isNotNull() & F.col("b").isNotNull() & (F.col("a") != F.col("b")))
            )
            edges_list.append(e)

    if not edges_list:
        # Return an empty DataFrame with the expected schema
        return df.sparkSession.createDataFrame([], schema="a string, b string")

    # 2. Union all edge lists using reduce
    edges_ud = edges_list[0]
    for e in edges_list[1:]:
        edges_ud = edges_ud.unionByName(e, allowMissingColumns=True)
        
    # 3. Apply distinct at the end
    return edges_ud.distinct()


def assign_unified_id_pyspark(
    df: DataFrame,
    match_columns: List[str],
    id_column: str = "unique_id",
    label_column: str = "dim_sellout_cust_id",
    max_iterations: int = 4
) -> DataFrame:
    """
    Assigns a Unified ID (Connected Component Label) using iterative Pure PySpark Label Propagation.
    This uses a combination of joins and a simplified window function approach for label updates.
    """
    
    # 1. Gather all unique, non-self edges (A -> B)
    edges_ud = _gather_edges(df, id_column, match_columns).localCheckpoint() # Optional: help performance on large edge lists

    if edges_ud.rdd.isEmpty():
        # Handle the trivial case where no edges exist
        return df.withColumn(label_column, F.col(id_column).cast("string"))

    # 2. Normalize and Create Undirected Edges (U < V)
    edges_norm = edges_ud.select(F.least("a", "b").alias("u"), F.greatest("a", "b").alias("v")).distinct()
    
    # 3. Create the full set of undirected edges (U -> V and V -> U)
    # This is crucial for bidirectional label propagation
    edges_undirected = edges_norm.select(F.col("u").alias("u"), F.col("v").alias("v")) \
        .unionByName(edges_norm.select(F.col("v").alias("u"), F.col("u").alias("v"))) \
        .distinct()

    # 4. All unique nodes (IDs)
    # Start with all IDs from the original DataFrame and the edges
    nodes_from_df = df.select(F.col(id_column).cast("string").alias("id")).filter(F.col("id").isNotNull())
    nodes_from_edges = edges_undirected.select(F.col("u").alias("id")).unionByName(edges_undirected.select(F.col("v").alias("id")))
    
    nodes = nodes_from_df.unionByName(nodes_from_edges).distinct().localCheckpoint()

    # 5. Initialize each node's label to itself (string comparison gives minimum label)
    labels = nodes.withColumn("label", F.col("id")).localCheckpoint()

    # 6. Label Propagation Loop
    for i in range(max_iterations):
        # A. Join current labels to the edges to get neighbor labels
        # e.u is the current node, e.v is its neighbor
        neighbor_labels = (
            edges_undirected.alias("e")
            .join(labels.alias("l"), F.col("e.v") == F.col("l.id"), "inner")
            # Select the source node (u) and its neighbor's label (l.label)
            .select(F.col("e.u").alias("id"), F.col("l.label").alias("nbr_label"))
            .localCheckpoint()
        )
        
        # B. Find the minimum neighbor label for each node (the core update)
        # Use a Window Function for minimum calculation (less overhead than group by in some contexts)
        # However, for min/max across all neighbors, groupBy is often more direct.
        # We will stick to the min/max approach, but simplify the join logic.
        
        # Original logic (GroupBy + Min) is the most efficient pattern here:
        min_neighbor_labels = (
            neighbor_labels.groupBy("id").agg(F.min("nbr_label").alias("min_nbr_label"))
        )
        
        # C. Update labels: take the minimum of the current label and the minimum neighbor label
        new_labels = (
            labels.alias("cur")
            .join(min_neighbor_labels.alias("nb"), "id", "left")
            .select(
                F.col("id"),
                # Choose the minimum of the current label and the minimum label of its neighbors
                F.when(F.col("nb.min_nbr_label").isNull(), F.col("cur.label"))
                 .otherwise(F.least(F.col("cur.label"), F.col("nb.min_nbr_label"))).alias("label")
            )
            .distinct()
            .localCheckpoint() # Checkpoint for convergence check stability
        )

        # D. Convergence check: see if any labels changed from the previous iteration
        # Note: If this check is too slow, you can rely solely on max_iterations
        changed_rows = new_labels.join(labels, ["id", "label"], "left_anti")
        
        if changed_rows.rdd.isEmpty(): # Optimized check using RDD
            labels = new_labels
            print(f"Convergence achieved after {i + 1} iterations.")
            break

        labels = new_labels
        print(f"Iteration {i + 1} completed.")
        
    # 7. Join Final Labels back to Original DataFrame
    df_base = df.withColumn("id_str_fb__", F.col(id_column).cast("string"))

    df_labeled = (
        df_base.join(labels.select(F.col("id"), F.col("label")), 
                     on=(F.col("id_str_fb__") == F.col("id")), 
                     how="left")
               .drop("id")
               # Any ID not found in the graph should keep its original ID as the label
               .withColumn(label_column, F.coalesce(F.col("label"), F.col("id_str_fb__")))
               .drop("label", "id_str_fb__")
    )
    
    return df_labeled
