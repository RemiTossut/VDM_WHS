# from imports import *
# ---------------------
# REQUIRED IMPORTS
# ---------------------

import warnings
warnings.filterwarnings("ignore", ".*sql_ctx is an internal property.*", UserWarning)

# PySpark
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import StringType, DoubleType

# Typing
from typing import Dict, Callable, List, Mapping, Optional

# Standard library
import json
from pyspark.sql import DataFrame, Column
from typing import List, Mapping, Optional, Callable, Dict
import pyspark.sql.functions as F
from pyspark.sql import Window


# Suppress the PySpark UserWarning that is triggered by GraphFrames' internal use of sql_ctx.
# We ignore this because the warning is in a third-party library, not our code.
warnings.filterwarnings("ignore", ".*sql_ctx is an internal property.*", UserWarning)

# matching_functions.py
# Utilities to apply exact and fuzzy (Levenshtein) matching rules and assign unified IDs.
# Designed for PySpark; no actions are triggered inside these functions.
# ---------------------------
# Matcher registry & utilities
# ---------------------------

_MATCHERS: Dict[str, Callable[..., DataFrame]] = {}


def register_matcher(name: str):
    """
    Decorator to register a matcher function under a name.

    Each matcher must have signature:
        fn(source: DataFrame, target: DataFrame, *, rule: Mapping, target_id_column: str, ...) -> DataFrame
    and return the *source* DataFrame with a new column (rule['result_column']) added.
    """
    def _decorator(func: Callable[..., DataFrame]):
        _MATCHERS[name] = func
        return func
    return _decorator


# Assuming _MATCHERS and other imports are defined elsewhere

from pyspark.sql import DataFrame, Column
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from typing import Mapping, List, Optional, Callable

# Assume _MATCHERS is defined globally, e.g.: _MATCHERS = {}


def apply_matching(
    *,
    source: DataFrame,
    target: DataFrame,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True,
    match_rules: List[Mapping],
    multiple_match_handler: str = 'multiple' # <--- NEW GLOBAL PARAMETER
) -> DataFrame:
    """
    Applies match rules sequentially, consolidating and joining results
    based on the single, globally set 'multiple_match_handler'.
    """
    if not source_id_column:
         raise ValueError("Source ID column must be provided for sequential matching with consolidation.")
    
    # Validation for the new parameter
    if multiple_match_handler not in ['multiple', 'best']:
        raise ValueError("multiple_match_handler must be 'multiple' or 'best'.")

    # 1. Initialize Base DataFrames and Result Tracker
    df_base = source.select(source.columns)
    # df_base = source.select("*")
    df_results = source.select(F.col(source_id_column).cast(StringType()).alias("_m_src_id_join_key")).dropDuplicates()
    
    final_match_cols = []

    for rule in match_rules:
        mtype = rule.get("match_type")
        out_col = rule.get("result_column")

        # ... (Validation checks remain the same) ...
        if not mtype:
            raise ValueError(f"Rule missing 'match_type': {rule}")
        matcher = _MATCHERS.get(mtype)
        if matcher is None:
            raise ValueError(f"No matcher registered for type '{mtype}'. Registered: {list(_MATCHERS)}")

        # 2. Apply the Matcher (Uses the clean source DF)
        df_matched_output = matcher(
            df_base, 
            target,
            rule=rule,
            target_id_column=target_id_column,
            source_id_column=source_id_column,
            id_matching_allowed=id_matching_allowed,
            # Pass the global handler down to the matcher function
            multiple_match_handler=multiple_match_handler # <--- PASSING THE GLOBAL VALUE
        )

        # 3. Extract and Prepare NEW Match Results (Same as before)
        match_cols_to_select = [out_col]
        # ... (logic to append score/details columns remains the same) ...
        if rule.get("score_column"):
            match_cols_to_select.append(rule["score_column"])
        if rule.get("comparison_details_column"):
            match_cols_to_select.append(rule["comparison_details_column"])
        if rule.get("value_dict_column"):
            match_cols_to_select.append(rule["value_dict_column"])

        df_new_results = df_matched_output.select(
            F.col(source_id_column).cast(StringType()).alias("_m_src_id_join_key"),
            *match_cols_to_select
        ).where(F.col(out_col).isNotNull()).dropDuplicates()

        # 4. Join New Results onto Accumulated Results (The Consolidation Pivot)
        current_cols_to_drop = [c for c in match_cols_to_select if c in df_results.columns]
        if current_cols_to_drop:
            df_results = df_results.drop(*current_cols_to_drop)

        # Join behavior is determined by the global handler
        join_how = "left" if multiple_match_handler == "best" else "full"

        df_results = df_results.join(
            df_new_results, 
            on="_m_src_id_join_key", 
            how=join_how
        )
        
        final_match_cols = list(dict.fromkeys(final_match_cols + match_cols_to_select))


    # 5. Final Projection (Same as before)
    df_base_keyed = df_base.withColumnRenamed(source_id_column, "_m_src_id_join_key")
    final_df = df_results.join(df_base_keyed, on="_m_src_id_join_key", how="left")
    final_df = final_df.withColumnRenamed("_m_src_id_join_key", source_id_column)
    final_cols = df_base.columns + final_match_cols
    
    return final_df.select([F.col(c) for c in final_cols]).distinct()
# ---------------------------
# EXACT matcher (symmetric)
# ---------------------------
from pyspark.sql import DataFrame, Column, Window
from pyspark.sql import functions as F
from typing import Mapping, List, Optional
# Assuming @register_matcher is defined elsewhere
@register_matcher("exact")
def exact_match(
    source: DataFrame,
    target: DataFrame,
    *,
    rule: Mapping,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True,
    multiple_match_handler: str = 'multiple'
) -> DataFrame:
    
    # --- 0. Setup and Argument Extraction ---
    column_pairs: List[Mapping] = rule.get("columns", [])
    if not column_pairs:
        raise ValueError("Exact match rule requires a 'columns' list for multi-column matching.")
        
    out_col = rule["result_column"]
    
    def normalize_expr(col_expr: Column, spec: Mapping) -> Column:
        """Applies trimming and case-insensitive transformations."""
        col_expr = col_expr.cast(StringType()) 
        if spec.get("trim_spaces_before_and_after", False):
            col_expr = F.trim(col_expr)
        if spec.get("make_case_insensitive", False):
            col_expr = F.upper(col_expr)
        return col_expr

    # --- 1. Prepare Source (Left) DF ---
    src = source
    source_cols_in_order = source.columns
    temp_src_cols_to_drop = [] 

    # Establish stable key (_m_src_key) for reconstruction
    normalized_src_cols = []
    if source_id_column:
        src = src.withColumn("_m_src_id", F.col(source_id_column).cast(StringType()))
        temp_src_cols_to_drop.append("_m_src_id")
        src = src.withColumn("_m_src_key", F.col("_m_src_id"))
    
    for i, pair in enumerate(column_pairs):
        alias = f"_m_src_{i}"
        src_col = pair["source_column"]
        src = src.withColumn(alias, normalize_expr(F.col(src_col), pair))
        normalized_src_cols.append(F.col(alias))
        temp_src_cols_to_drop.append(alias)
        
    if not source_id_column:
        src = src.withColumn(
            "_m_src_key",
            F.sha2(F.concat_ws("|", *normalized_src_cols), 256)
        )
    # Note: temp_src_cols_to_drop is for temp cleanup; we keep _m_src_key until the final join.
    if "_m_src_key" not in temp_src_cols_to_drop:
        temp_src_cols_to_drop.append("_m_src_key")

    # --- 2. Prepare Target (Right) DF ---
    tgt_selects = [F.col(target_id_column).cast(StringType()).alias("_m_tgt_id")]
    for i, pair in enumerate(column_pairs):
        alias = f"_m_tgt_{i}"
        tgt_col = pair["target_column"]
        tgt_selects.append(normalize_expr(F.col(tgt_col), pair).alias(alias))
    
    tgt = target.select(*tgt_selects)

    # --- 3. Build Compound Join Condition ---
    join_expr: Optional[Column] = None
    for i in range(len(column_pairs)):
        src_col_alias = f"_m_src_{i}"
        tgt_col_alias = f"_m_tgt_{i}"

        cond_i = (
            F.col(src_col_alias).isNotNull() & F.col(tgt_col_alias).isNotNull() & 
            (F.col(src_col_alias) == F.col(tgt_col_alias))
        )
        join_expr = cond_i if join_expr is None else (join_expr & cond_i)

    if join_expr is None:
        raise ValueError("Join condition is empty.")
        
    # --- 4. Perform Join and Identify Candidates ---
    joined = src.alias("s").join(tgt.alias("t"), on=join_expr, how="left")
    
    # 💥 CRITICAL FIX: DEFINE 'candidates' HERE 💥
    candidates = joined.select(
        *[F.col(f"s.{c}") for c in src.columns],
        F.col("t._m_tgt_id").alias("_m_id")
    )

    # Apply Self-Match Exclusion
    if not id_matching_allowed and source_id_column:
        candidates = candidates.withColumn(
            "_m_id",
            F.when(F.col("_m_id").isNotNull() & (F.col("_m_id") == F.col("_m_src_id")), F.lit(None).cast(StringType()))
            .otherwise(F.col("_m_id"))
        )
    
    # --- 5. Conditional Output based on multiple_match_handler ---
    if multiple_match_handler == 'best':
        # Pick Best Candidate (One-to-One)
        w = Window.partitionBy("_m_src_key").orderBy(F.col("_m_id").asc())
        
        picked = (
            candidates.where(F.col("_m_id").isNotNull())
            .withColumn("_m_rn", F.row_number().over(w))
            .where(F.col("_m_rn") == 1)
            .select(
                F.col("_m_src_key"), 
                F.col("_m_id").alias(out_col)
            )
        )
        
        # Select only original columns and key from src for a clean join base
        final_src_base = src.select(*source_cols_in_order, F.col("_m_src_key"))

        final = final_src_base.join(picked, on="_m_src_key", how="left")
        
        # Drop the temporary key column AFTER the join
        final = final.drop("_m_src_key")

        return final.select(*source_cols_in_order, out_col)

    elif multiple_match_handler == 'multiple':
        # Return All Candidates (One-to-Many / Duplicate Rows)
        
        # 1. Separate Matched and Unmatched, and CLEAN the dataframes
        
        # Matched rows: Select only original columns, the new match column, and the key
        matched_rows = candidates.where(F.col("_m_id").isNotNull()).select(
            *[F.col(c) for c in source_cols_in_order],
            F.col("_m_id").alias(out_col),
            F.col("_m_src_key")
        )
        
        # Unmatched rows: Get keys that did not match
        all_keys = src.select("_m_src_key")
        matched_keys = matched_rows.select("_m_src_key").distinct()
        unmatched_keys = all_keys.exceptAll(matched_keys)
        
        # Create a clean base source DF containing only original columns + key
        unmatched_src_base = src.select(*source_cols_in_order, F.col("_m_src_key"))

        # Join the unmatched keys back to the clean source base to get original columns
        unmatched_src = unmatched_src_base.join(unmatched_keys, on="_m_src_key", how="inner").select(
            *[F.col(c) for c in source_cols_in_order],
            F.lit(None).cast(StringType()).alias(out_col)
        )
        
        # Drop _m_src_key from matched_rows before union
        final = matched_rows.drop("_m_src_key").unionByName(unmatched_src)
        
        return final.select(*source_cols_in_order, out_col)

    else:
        raise ValueError(f"Invalid multiple_match_handler: {multiple_match_handler}. Must be 'multiple' or 'best'.")

# ... (Imports and setup from previous response) ...
@register_matcher("levenstein")
def levenstein_match(
    source: DataFrame,
    target: DataFrame,
    *,
    rule: Mapping,
    target_id_column: str,
    source_id_column: Optional[str] = None,
    id_matching_allowed: bool = True,
    multiple_match_handler: str = 'multiple'
) -> DataFrame:
    
    # --- 0. Setup and Argument Extraction ---
    columns: List[Mapping] = rule["columns"]
    out_col = rule["result_column"]
    score_col = rule.get("score_column", "levenstein_score")
    details_col = rule.get("comparison_details_column", "match_details")
    value_dict_col = rule.get("value_dict_column", "value_dict")
    min_score = float(rule.get("min_score", 0.0))

    exact_match_specs = [c for c in columns if c.get("match") == "exact"]
    if not exact_match_specs:
         raise ValueError("Levenstein match rule must contain at least one column with match='exact' for the primary join key.")
    
    primary_join_col_source = exact_match_specs[0]["source_column"]
    primary_join_col_target = exact_match_specs[0]["target_column"]

    def normalize_expr(col_expr: Column, spec: Mapping) -> Column:
        """Applies trimming and case-insensitive transformations."""
        col_expr = col_expr.cast(StringType())
        if spec.get("trim_spaces_before_and_after", False):
            col_expr = F.trim(col_expr)
        if spec.get("make_case_insensitive", False):
            col_expr = F.upper(col_expr)
        return col_expr

    # --- 1. Prepare Source (Left) DF and Target (Right) DF ---
    src = source
    target_df = target
    source_cols_in_order = source.columns
    temp_src_cols_to_drop = []
    
    # Create stable source key and ID
    normalized_src_cols = []
    if source_id_column:
        src = src.withColumn("_m_src_id", F.col(source_id_column).cast(StringType()))
        temp_src_cols_to_drop.append("_m_src_id")
        src = src.withColumn("_m_src_key", F.col("_m_src_id"))
    
    for i, spec in enumerate(columns):
        src_alias = f"_m_src_{i}"
        src = src.withColumn(src_alias, normalize_expr(F.col(spec["source_column"]), spec))
        normalized_src_cols.append(F.col(src_alias))
        temp_src_cols_to_drop.append(src_alias)
        
        # Target side
        tgt_alias = f"_m_tgt_{i}"
        target_df = target_df.withColumn(tgt_alias, normalize_expr(F.col(spec["target_column"]), spec).alias(tgt_alias))
    
    if not source_id_column:
        src = src.withColumn("_m_src_key", F.sha2(F.concat_ws("|", *normalized_src_cols), 256))
    temp_src_cols_to_drop.append("_m_src_key")

    # Select only the target ID and the normalized target columns
    tgt_selects = [F.col(target_id_column).alias("_m_tgt_id")] + [F.col(f"_m_tgt_{i}") for i in range(len(columns))]
    tgt = target_df.select(*tgt_selects)

    # --- 2. Build Standard Join Condition (using the primary exact match column) ---
    def get_normalized_alias_index(col_name: str, df_side: str) -> str:
        for i, spec in enumerate(columns):
            if spec["source_column"] == col_name or spec["target_column"] == col_name:
                return f"_m_{df_side}_{i}"
        raise ValueError(f"Join column '{col_name}' not found in rule 'columns'.")

    primary_a_alias = get_normalized_alias_index(primary_join_col_source, 'src')
    primary_b_alias = get_normalized_alias_index(primary_join_col_target, 'tgt')
    
    join_expr: Column = (
        F.col(primary_a_alias).isNotNull() &
        F.col(primary_b_alias).isNotNull() &
        (F.col(primary_a_alias) == F.col(primary_b_alias))
    )

    # --- 3. Perform LEFT Join to find all candidates ---
    joined = src.alias("s").join(tgt.alias("t"), on=join_expr, how="left")
    
    # **FIXED DEFINITION OF 'candidates'** # Select all necessary columns into a single unaliased DataFrame: 'candidates'
    candidates = joined.select(
        # Original and temp source columns
        *[F.col(f"s.{c}") for c in src.columns], 
        # Normalized target columns
        *[F.col(f"t._m_tgt_{i}").alias(f"_m_tgt_{i}") for i in range(len(columns))], 
        # Target ID
        F.col("t._m_tgt_id").alias("_m_tgt_id") 
    )

    # --- 4. Apply Self-Match Exclusion and SPLIT ---
    if (not id_matching_allowed) and source_id_column:
        candidates = candidates.withColumn(
            "_m_tgt_id",
            F.when(F.col("_m_tgt_id") == F.col("_m_src_id"), F.lit(None).cast(StringType()))
            .otherwise(F.col("_m_tgt_id"))
        )

    # Split matched candidates (for score calculation) from unmatched source rows (for final union)
    matched_candidates = candidates.where(F.col("_m_tgt_id").isNotNull())
    
    # We only need the source key for the unmatched set
    unmatched_src_keys = candidates.where(F.col("_m_tgt_id").isNull()).select("_m_src_key")
    
    # --- 5. Compute Similarity and Score ---
    df = matched_candidates # df is the DataFrame used for scoring
    detail_structs = []
    score_terms = []
    temp_sim_cols = []
    match_cols_for_select = [out_col, score_col, details_col]
    if value_dict_col:
        match_cols_for_select.append(value_dict_col)

    # Calculate scores and build match details structure
    for i, spec in enumerate(columns):
        src_col_alias = f"_m_src_{i}"
        tgt_col_alias = f"_m_tgt_{i}"
        src_col = F.col(src_col_alias)
        tgt_col = F.col(tgt_col_alias)

        if spec.get("match") == "exact":
            detail_structs.append(
                F.struct(F.lit(spec["source_column"]).alias("column"), F.lit(1.0).alias("similarity"),
                         src_col.alias("source_value"), tgt_col.alias("target_value"), F.lit("exact").alias("match_type"))
            )
        elif spec.get("match") == "fuzzy":
            weight = float(spec.get("weight", 1.0))
            dist_col = F.levenshtein(src_col, tgt_col)
            max_len = F.greatest(F.length(src_col), F.length(tgt_col))
            sim_col = F.when(max_len == 0, 1.0).otherwise(1.0 - dist_col.cast(DoubleType()) / max_len.cast(DoubleType()))
            sim_alias = f"_m_sim_{i}"
            df = df.withColumn(sim_alias, sim_col)
            score_terms.append(F.col(sim_alias) * F.lit(weight))
            temp_sim_cols.append(sim_alias)
            detail_structs.append(
                F.struct(F.lit(spec["source_column"]).alias("column"), F.col(sim_alias).alias("similarity"),
                         src_col.alias("source_value"), tgt_col.alias("target_value"), F.lit("fuzzy").alias("match_type"))
            )

    fuzzy_cols = [c for c in columns if c.get("match") == "fuzzy"]
    if score_terms:
        total_weight = sum(float(c.get("weight", 1.0)) for c in fuzzy_cols) or 1.0
        df = df.withColumn(score_col, sum(score_terms) / F.lit(total_weight))
    else:
        df = df.withColumn(score_col, F.lit(0.0).cast(DoubleType()))

    # Apply min_score filter
    df = df.where(F.col(score_col) >= F.lit(min_score))

    # Build details and value_dict structure
    details_array = F.array(*detail_structs)
    df = df.withColumn(details_col, F.to_json(details_array))

    value_dict_struct = F.struct(F.col("_m_tgt_id").alias("target_id"), F.col(score_col).alias("score"), details_array.alias("columns_compared"))
    if value_dict_col:
        df = df.withColumn(value_dict_col, F.to_json(value_dict_struct))

    # --- 6. Conditional Output based on multiple_match_handler ---
        
    if multiple_match_handler == 'best':
        # Pick Best Candidate (One-to-One)
        w = Window.partitionBy("_m_src_key").orderBy(F.col(score_col).desc(), F.col("_m_tgt_id").asc())
        
        picked = (
            df.withColumn("_m_rn", F.row_number().over(w))
            .where(F.col("_m_rn") == 1)
            .select(F.col("_m_src_key"), F.col("_m_tgt_id").alias(out_col), *match_cols_for_select[1:])
        )
        
        final_src_base = src.select(*source_cols_in_order, F.col("_m_src_key"))

        final_with_matches = final_src_base.join(picked, on="_m_src_key", how="left")

        final = final_with_matches.drop("_m_src_key")

        return final.select(*source_cols_in_order, *match_cols_for_select)
        
    elif multiple_match_handler == 'multiple':
        # Return All Candidates (One-to-Many / Duplicate Rows)
        
        # 1. Matched Rows: Select only relevant columns from the scored DF (`df`)
        matched_final = df.select(
            *[F.col(c) for c in source_cols_in_order],
            F.col("_m_src_key"), # Keep key for filtering/union
            F.col("_m_tgt_id").alias(out_col),
            *match_cols_for_select[1:] 
        )
        
        # 2. Unmatched Rows: Use the previously extracted keys
        unmatched_keys = unmatched_src_keys # Keys from Step 4
        
        # Create a clean base source DF containing only original columns + key
        unmatched_src_base = src.select(*source_cols_in_order, F.col("_m_src_key"))

        # Join the unmatched keys back to the clean source base
        unmatched_final = unmatched_src_base.join(unmatched_keys, on="_m_src_key", how="inner").select(
            *[F.col(c) for c in source_cols_in_order],
            F.lit(None).cast(StringType()).alias(out_col),
            F.lit(None).cast(DoubleType()).alias(score_col),
            F.lit(None).cast(StringType()).alias(details_col),
            *([F.lit(None).cast(StringType()).alias(value_dict_col)] if value_dict_col else [])
        )
        
        # Drop _m_src_key from both before union
        final = matched_final.drop("_m_src_key").unionByName(unmatched_final.drop("_m_src_key"))
        
        return final.select(*source_cols_in_order, *match_cols_for_select)

    else:
        raise ValueError(f"Invalid multiple_match_handler: {multiple_match_handler}. Must be 'multiple' or 'best'.")

# ---------------------------------
# Assign unified (component) ID label
# ---------------------------------

def _gather_edges(df: DataFrame, id_column: str, match_columns: List[str]) -> DataFrame:
    """
    Gathers all valid (src, dst) edges from the id_column to all match_columns.
    Returns edges as two columns: a, b (strings), with a != b, distinct.
    """
    
    # 1. Create a list of edge DataFrames
    edges_list = []
    
    for col in match_columns:
        if col in df.columns:
            e = (
                df.select(
                    F.col(id_column).cast("string").alias("a"),
                    F.col(col).cast("string").alias("b")
                )
                # Ensure neither ID is null and they are not matching themselves
                .where(F.col("a").isNotNull() & F.col("b").isNotNull() & (F.col("a") != F.col("b")))
            )
            edges_list.append(e)

    if not edges_list:
        # Return an empty DataFrame with the expected schema
        return df.sparkSession.createDataFrame([], schema="a string, b string")

    # 2. Union all edge lists using reduce
    edges_ud = edges_list[0]
    for e in edges_list[1:]:
        edges_ud = edges_ud.unionByName(e, allowMissingColumns=True)
        
    # 3. Apply distinct at the end
    return edges_ud.distinct()


def assign_unified_id_pyspark(
    df: DataFrame,
    match_columns: List[str],
    id_column: str = "unique_id",
    label_column: str = "dim_sellout_cust_id",
    max_iterations: int = 4
) -> DataFrame:
    """
    Assigns a Unified ID (Connected Component Label) using iterative Pure PySpark Label Propagation.
    This uses a combination of joins and a simplified window function approach for label updates.
    """
    
    # 1. Gather all unique, non-self edges (A -> B)
    edges_ud = _gather_edges(df, id_column, match_columns).localCheckpoint() # Optional: help performance on large edge lists

    if edges_ud.rdd.isEmpty():
        # Handle the trivial case where no edges exist
        return df.withColumn(label_column, F.col(id_column).cast("string"))

    # 2. Normalize and Create Undirected Edges (U < V)
    edges_norm = edges_ud.select(F.least("a", "b").alias("u"), F.greatest("a", "b").alias("v")).distinct()
    
    # 3. Create the full set of undirected edges (U -> V and V -> U)
    # This is crucial for bidirectional label propagation
    edges_undirected = edges_norm.select(F.col("u").alias("u"), F.col("v").alias("v")) \
        .unionByName(edges_norm.select(F.col("v").alias("u"), F.col("u").alias("v"))) \
        .distinct()

    # 4. All unique nodes (IDs)
    # Start with all IDs from the original DataFrame and the edges
    nodes_from_df = df.select(F.col(id_column).cast("string").alias("id")).filter(F.col("id").isNotNull())
    nodes_from_edges = edges_undirected.select(F.col("u").alias("id")).unionByName(edges_undirected.select(F.col("v").alias("id")))
    
    nodes = nodes_from_df.unionByName(nodes_from_edges).distinct().localCheckpoint()

    # 5. Initialize each node's label to itself (string comparison gives minimum label)
    labels = nodes.withColumn("label", F.col("id")).localCheckpoint()

    # 6. Label Propagation Loop
    for i in range(max_iterations):
        # A. Join current labels to the edges to get neighbor labels
        # e.u is the current node, e.v is its neighbor
        neighbor_labels = (
            edges_undirected.alias("e")
            .join(labels.alias("l"), F.col("e.v") == F.col("l.id"), "inner")
            # Select the source node (u) and its neighbor's label (l.label)
            .select(F.col("e.u").alias("id"), F.col("l.label").alias("nbr_label"))
            .localCheckpoint()
        )
        
        # B. Find the minimum neighbor label for each node (the core update)
        # Use a Window Function for minimum calculation (less overhead than group by in some contexts)
        # However, for min/max across all neighbors, groupBy is often more direct.
        # We will stick to the min/max approach, but simplify the join logic.
        
        # Original logic (GroupBy + Min) is the most efficient pattern here:
        min_neighbor_labels = (
            neighbor_labels.groupBy("id").agg(F.min("nbr_label").alias("min_nbr_label"))
        )
        
        # C. Update labels: take the minimum of the current label and the minimum neighbor label
        new_labels = (
            labels.alias("cur")
            .join(min_neighbor_labels.alias("nb"), "id", "left")
            .select(
                F.col("id"),
                # Choose the minimum of the current label and the minimum label of its neighbors
                F.when(F.col("nb.min_nbr_label").isNull(), F.col("cur.label"))
                 .otherwise(F.least(F.col("cur.label"), F.col("nb.min_nbr_label"))).alias("label")
            )
            .distinct()
            .localCheckpoint() # Checkpoint for convergence check stability
        )

        # D. Convergence check: see if any labels changed from the previous iteration
        # Note: If this check is too slow, you can rely solely on max_iterations
        changed_rows = new_labels.join(labels, ["id", "label"], "left_anti")
        
        if changed_rows.rdd.isEmpty(): # Optimized check using RDD
            labels = new_labels
            print(f"Convergence achieved after {i + 1} iterations.")
            break

        labels = new_labels
        print(f"Iteration {i + 1} completed.")
        
    # 7. Join Final Labels back to Original DataFrame
    df_base = df.withColumn("id_str_fb__", F.col(id_column).cast("string"))

    df_labeled = (
        df_base.join(labels.select(F.col("id"), F.col("label")), 
                     on=(F.col("id_str_fb__") == F.col("id")), 
                     how="left")
               .drop("id")
               # Any ID not found in the graph should keep its original ID as the label
               .withColumn(label_column, F.coalesce(F.col("label"), F.col("id_str_fb__")))
               .drop("label", "id_str_fb__")
    )
    
    return df_labeled
