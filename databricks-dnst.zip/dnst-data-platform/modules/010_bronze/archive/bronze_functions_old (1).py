# bronze_functions.py

from imports import *

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------
def clean_spark_column_name(col_name: str) -> str:
    cleaned_name = re.sub(r'[^\w\s]', ' ', col_name)
    cleaned_name = re.sub(r'\s+', '_', cleaned_name)
    cleaned_name = cleaned_name.strip(' _')
    cleaned_name = cleaned_name.lower()
    return cleaned_name

# ---------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------
def get_excel_data(spark, excel_path: str) -> DataFrame:
    """
    Reads CSV files from the given path into a Spark DataFrame, cleans column names,
    and adds a column for the source file path.
    """
    print(f"Reading CSV files from: {excel_path}")
    df_excel = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .option("delimiter", ",")
        .load(excel_path)
    )

    # Clean column names immediately after loading
    for old_col_name in df_excel.columns:
        new_col_name = clean_spark_column_name(old_col_name)
        if old_col_name != new_col_name:
            df_excel = df_excel.withColumnRenamed(old_col_name, new_col_name)

    # Path column (prefer _metadata.file_path when present; otherwise use input_file_name)
    # df_excel = df_excel.withColumn("full_file_path", F.input_file_name())
    df_excel = df_excel.withColumn("full_file_path", F.col("_metadata.file_path"))

    print(f"Successfully read CSV files. Rows: {df_excel.count()}")
    return df_excel


def get_staged_csv_data(file_path: str, csv_read_config: dict) -> pd.DataFrame:
    """
    Reads a CSV file from a local or mounted path into a pandas DataFrame,
    applying specific read configurations, and skips malformed lines.
    """
    print(f"  Reading staged CSV from: {file_path}")
    try:
        encoding = csv_read_config.get('encoding', 'utf-8')

        # Read file content using standard open()
        with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
            csv_content = f.read()

        csv_io = BytesIO(csv_content.encode(encoding))

        # First attempt
        df_raw = pd.read_csv(csv_io, **csv_read_config)
        df_raw["full_file_path"] = file_path

        print(f"  Successfully read CSV with {len(df_raw)} rows (bad lines skipped).")
        return df_raw

    except pd.errors.ParserError as e:
        print(f"⚠️ Parser error in '{file_path}': {e}")
        print("Retrying with python engine (slower but more tolerant)...")

        csv_io.seek(0)
        df_raw = pd.read_csv(csv_io, engine='python', **csv_read_config)
        df_raw["full_file_path"] = file_path
        print(f"  Successfully read CSV with {len(df_raw)} rows (after retry).")
        return df_raw

    except Exception as e:
        print(f"❌ Error reading staged CSV '{file_path}': {e}")
        raise

# ---------------------------------------------------------------------
# Transform
# ---------------------------------------------------------------------

def process_excel_to_golden_dataframe(
    spark, 
    df_excel: DataFrame,
    wholesaler_name: str,
    column_mapping: dict,
    golden_schema: dict
) -> DataFrame:
    
    print(f"Processing data for wholesaler: {wholesaler_name}")
    casted_cols = []

    # 1. CREATE CASE-INSENSITIVE LOOKUP MAP
    # Maps 'klantnummer' -> 'Klantnummer', 'totaal' -> 'Totaal', etc.
    raw_column_map: Dict[str, str] = {col.lower(): col for col in df_excel.columns}

    for golden_col_name, golden_col_type in golden_schema.items():
        # The value from the config (e.g., 'klantnummer' or 'totaal')
        excel_col_mapping = column_mapping.get(golden_col_name)
        
        # Determine the target column name (cased) in the raw DataFrame
        target_col_cased = None
        
        # --- Common Logic for Column Selection (Now Case-Insensitive) ---
        if isinstance(excel_col_mapping, list):
            # Case 1: list of possible columns (first present wins, check lowercase)
            for c in excel_col_mapping:
                if isinstance(c, str) and c.lower() in raw_column_map:
                    target_col_cased = raw_column_map[c.lower()]
                    break
        elif isinstance(excel_col_mapping, str):
            # Case 3: single column name (lookup using lowercase name)
            if excel_col_mapping.lower() in raw_column_map:
                target_col_cased = raw_column_map[excel_col_mapping.lower()]

        
        # --- Apply Mapping and Casting ---
        if target_col_cased:
            col_expr = F.col(target_col_cased)
            
            # **IMPORTANT: The logic to fix the comma-decimal issue remains essential**
            if golden_col_name == "total_amount" and golden_col_type.upper() == "DOUBLE":
                # Assumes the raw column is a string that needs cleanup (e.g., "Totaal")
                col_expr = F.regexp_replace(col_expr, r',', '.')
                casted_cols.append(col_expr.cast("DOUBLE").alias(golden_col_name))
                # print(f"✔ Using column '{target_col_cased}' (case-insensitive) for '{golden_col_name}', fixing decimal.")
            
            # Handle Date/Timestamp casting
            elif golden_col_type.upper() == "DATE":
                casted_cols.append(F.to_date(col_expr).alias(golden_col_name))
            elif golden_col_type.upper() == "TIMESTAMP":
                casted_cols.append(F.to_timestamp(col_expr).alias(golden_col_name))
            
            # Standard cast
            else:
                casted_cols.append(col_expr.cast(golden_col_type).alias(golden_col_name))

        # Case 2: Spark Column (e.g., F.lit(...) or expression) - does not require lookup
        elif isinstance(excel_col_mapping, Column):
            casted_cols.append(excel_col_mapping.cast(golden_col_type).alias(golden_col_name))
            print(f"✔ Applying literal/complex mapping for '{golden_col_name}'.")

        # Case 4: missing/invalid mapping
        else:
            casted_cols.append(F.lit(None).cast(golden_col_type).alias(golden_col_name))
            # Only print warning if a mapping was actually provided but failed
            if excel_col_mapping is not None:
                print(f"⚠ Column name '{excel_col_mapping}' not found (even case-insensitively) for '{golden_col_name}'. Adding NULL.")
            else:
                print(f"⚠ No mapping provided for '{golden_col_name}'. Adding NULL.")

    df_golden = df_excel.select(*casted_cols)
    print(f"✅ Defined lazy transformation for {wholesaler_name}.")
    
    return df_golden
# ---------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------
def process_wholesaler_csv_files(
    spark: SparkSession,
    wholesaler_name: str,
    config: Mapping,
    base_volume_path: str,
    bronze_base_table_path: str,
    golden_template_schema: Optional[str] = None
) -> DataFrame:
    
    # --- 1. Setup and Path Definition ---
    raw_folder_name = config["folder_name"]
    folder_name = re.sub(r'[^A-Za-z0-9]', '_', raw_folder_name)
    file_pattern = '/*.csv' 
    column_mapping = config["column_mapping"]
    csv_read_config = config.get("csv_read_config", {})
    
    folder_path = f"{base_volume_path}/{folder_name}/*"
    full_path_with_wildcard = f"{folder_path}{file_pattern}"
    
    print(f"Defining lazy read operation for path: {full_path_with_wildcard}")

    # --- 2. Lazy Read Operation ---
    # try:
    #     reader = spark.read.format("csv")
    #     spark_csv_options = {
    #         'header': 'true', 
    #         'inferSchema': 'false', 
    #         **csv_read_config 
    #     }
    #     for key, value in spark_csv_options.items():
    #         reader = reader.option(key, value)

    #     df_raw_csv_spark = reader.load(full_path_with_wildcard).withColumn("full_file_path", F.input_file_name())
    #     # df_raw_csv_spark.printSchema()

    df_raw_csv_pd = pd.read_csv(full_path_with_wildcard, **csv_read_config)
    df_raw_csv_spark = spark.createDataFrame(df_raw_csv_pd)
        
    # except Exception as e:
    #     print(f"Error during lazy file path definition: {e}")
    #     return spark.createDataFrame([], golden_template_schema)

    # 🔑 CRITICAL FIX: LOWERCASE ALL COLUMN NAMES 🔑
    # This ensures consistency and makes all mapping expressions case-insensitive.
    for col in df_raw_csv_spark.columns:
        df_raw_csv_spark = df_raw_csv_spark.withColumnRenamed(col, col.lower().replace('-', '_').replace(' ', '_'))
        df_raw_csv_spark.printSchema()
    
    print("Column names converted to lowercase and snake_case for mapping consistency.")
    
    # --- 3. Conform to Golden Schema (Lazy Transformation) ---
    # Since all raw columns are now lowercase, the config should use lowercase column names.
    df_golden_template = process_excel_to_golden_dataframe(
        spark,
        df_raw_csv_spark,
        wholesaler_name,
        column_mapping,
        golden_template_schema
    )

    # --- 4. Filter and Return (Lazy Transformations) ---
    df_result = (
        df_golden_template
        .filter(F.col("customer_number").isNotNull())
        .filter(F.col("total_amount").isNotNull())
    )
    
    return df_result
