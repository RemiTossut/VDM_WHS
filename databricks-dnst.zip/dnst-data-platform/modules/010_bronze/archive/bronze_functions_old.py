# bronze_functions.py

from imports import *

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------
def clean_spark_column_name(col_name: str) -> str:
    cleaned_name = re.sub(r'[^\w\s]', ' ', col_name)
    cleaned_name = re.sub(r'\s+', '_', cleaned_name)
    cleaned_name = cleaned_name.strip(' _')
    cleaned_name = cleaned_name.lower()
    return cleaned_name

# ---------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------
def get_excel_data(spark, excel_path: str) -> DataFrame:
    """
    Reads CSV files from the given path into a Spark DataFrame, cleans column names,
    and adds a column for the source file path.
    """
    print(f"Reading CSV files from: {excel_path}")
    df_excel = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .option("delimiter", ",")
        .load(excel_path)
    )

    # Clean column names immediately after loading
    for old_col_name in df_excel.columns:
        new_col_name = clean_spark_column_name(old_col_name)
        if old_col_name != new_col_name:
            df_excel = df_excel.withColumnRenamed(old_col_name, new_col_name)

    # Path column (prefer _metadata.file_path when present; otherwise use input_file_name)
    # df_excel = df_excel.withColumn("full_file_path", F.input_file_name())
    df_excel = df_excel.withColumn("full_file_path", F.col("_metadata.file_path"))

    print(f"Successfully read CSV files. Rows: {df_excel.count()}")
    return df_excel


def get_staged_csv_data(file_path: str, csv_read_config: dict) -> pd.DataFrame:
    """
    Reads a CSV file from a local or mounted path into a pandas DataFrame,
    applying specific read configurations, and skips malformed lines.
    """
    print(f"  Reading staged CSV from: {file_path}")
    try:
        encoding = csv_read_config.get('encoding', 'utf-8')

        # Read file content using standard open()
        with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
            csv_content = f.read()

        csv_io = BytesIO(csv_content.encode(encoding))

        # First attempt
        df_raw = pd.read_csv(csv_io, **csv_read_config)
        df_raw["full_file_path"] = file_path

        print(f"  Successfully read CSV with {len(df_raw)} rows (bad lines skipped).")
        return df_raw

    except pd.errors.ParserError as e:
        print(f"⚠️ Parser error in '{file_path}': {e}")
        print("Retrying with python engine (slower but more tolerant)...")

        csv_io.seek(0)
        df_raw = pd.read_csv(csv_io, engine='python', **csv_read_config)
        df_raw["full_file_path"] = file_path
        print(f"  Successfully read CSV with {len(df_raw)} rows (after retry).")
        return df_raw

    except Exception as e:
        print(f"❌ Error reading staged CSV '{file_path}': {e}")
        raise

# ---------------------------------------------------------------------
# Transform
# ---------------------------------------------------------------------
def process_excel_to_golden_dataframe(
    spark,                     # kept for consistency / future use
    df_excel: DataFrame,
    wholesaler_name: str,
    column_mapping: dict,
    golden_schema: dict
) -> DataFrame:
    """
    Transforms a raw Excel DataFrame into a golden template DataFrame.
    Handles:
      - Single column mappings (string)
      - Multiple fallback columns (list)
      - Complex mappings or literals (Spark Column, e.g., F.lit)
      - Missing mappings (None → NULL)
    """
    print(f"Processing data for wholesaler: {wholesaler_name}")
    casted_cols = []

    for golden_col_name, golden_col_type in golden_schema.items():
        excel_col_mapping = column_mapping.get(golden_col_name)
        print(f"Mapping for '{golden_col_name}': {excel_col_mapping}")

        # Case 1: list of possible columns (first present wins)
        if isinstance(excel_col_mapping, list):
            target_col = next((c for c in excel_col_mapping if c in df_excel.columns), None)
            if target_col:
                casted_cols.append(F.col(target_col).cast(golden_col_type).alias(golden_col_name))
                print(f"✔ Found column '{target_col}' for '{golden_col_name}'.")
            else:
                print(f"⚠ None of {excel_col_mapping} found for '{golden_col_name}'. Adding NULL.")
                casted_cols.append(F.lit(None).cast(golden_col_type).alias(golden_col_name))

        # Case 2: Spark Column (e.g., F.lit(...) or expression)
        elif hasattr(excel_col_mapping, "alias"):
            print(f"✔ Applying literal/complex mapping for '{golden_col_name}'.")
            casted_cols.append(excel_col_mapping.cast(golden_col_type).alias(golden_col_name))

        # Case 3: single column name
        elif isinstance(excel_col_mapping, str) and excel_col_mapping in df_excel.columns:
            if str(golden_col_type).upper() == "DATE":
                casted_cols.append(F.to_date(F.col(excel_col_mapping)).alias(golden_col_name))
            elif str(golden_col_type).upper() == "TIMESTAMP":
                casted_cols.append(F.to_timestamp(F.col(excel_col_mapping)).alias(golden_col_name))
            else:
                casted_cols.append(F.col(excel_col_mapping).cast(golden_col_type).alias(golden_col_name))
            print(f"✔ Using column '{excel_col_mapping}' for '{golden_col_name}'.")

        # Case 4: missing/invalid mapping
        else:
            if excel_col_mapping is not None:
                print(f"⚠ Column for '{golden_col_name}' (expected '{excel_col_mapping}') not found. Adding NULL.")
            else:
                print(f"⚠ No mapping provided for '{golden_col_name}'. Adding NULL.")
            casted_cols.append(F.lit(None).cast(golden_col_type).alias(golden_col_name))

    df_golden = df_excel.select(*casted_cols)
    print(f"✅ Transformed data for {wholesaler_name}. Row count: {df_golden.count()}")
    return df_golden

# ---------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------
def process_wholesaler_csv_files(
    spark,
    wholesaler_name,
    config,
    base_volume_path,
    bronze_base_table_path,
    golden_template_schema
):
    raw_folder_name = config["folder_name"]
    folder_name = re.sub(r'[^A-Za-z0-9]', '_', raw_folder_name)  # sanitize
    file_pattern = '*.csv'
    column_mapping = config["column_mapping"]
    csv_read_config = config.get("csv_read_config", {})

    customer_bronze_table_name = f"{bronze_base_table_path}.{wholesaler_name}"

    # Find files
    folder_path = f"{base_volume_path}/{folder_name}/*/{file_pattern}"
    matching_files = glob.glob(folder_path)
    print(f"Found {len(matching_files)} files for {wholesaler_name}, using folder path {folder_path}")

    df_result = None

    for file_path in matching_files:
        try:
            print(f"\nProcessing file: {file_path}")

            # Step 1: read staged CSV
            if csv_read_config:
                df_raw_csv = get_staged_csv_data(file_path, csv_read_config)    # pandas DF
                print("df_raw_csv rows: ", len(df_raw_csv))
                df_raw_csv_spark = spark.createDataFrame(df_raw_csv)           # to Spark
            else:
                df_raw_csv_spark = get_excel_data(spark, file_path)

            # Step 2: conform to golden schema
            df_golden_template = process_excel_to_golden_dataframe(
                spark,
                df_raw_csv_spark,
                wholesaler_name,
                column_mapping,
                golden_template_schema
            )

            # Step 3: filter and union
            filtered_df = (
                df_golden_template
                .filter(F.col("customer_number").isNotNull())
                .filter(F.col("total_amount").isNotNull())
            )

            if df_result is None:
                df_result = filtered_df
            else:
                df_result = df_result.unionByName(filtered_df)

        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

    return df_result
