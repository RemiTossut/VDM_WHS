# bronze_functions.py

from imports import *

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------
def clean_spark_column_name(col_name: str) -> str:
    cleaned_name = re.sub(r'[^\w\s]', ' ', col_name)
    cleaned_name = re.sub(r'\s+', '_', cleaned_name)
    cleaned_name = cleaned_name.strip(' _')
    cleaned_name = cleaned_name.lower()
    return cleaned_name

# ---------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------
def get_excel_data(spark, excel_path: str) -> DataFrame:
    """
    Reads CSV files from the given path into a Spark DataFrame, cleans column names,
    and adds a column for the source file path.
    """
    print(f"Reading CSV files from: {excel_path}")
    df_excel = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .option("delimiter", ",")
        .load(excel_path)
    )

    # Clean column names immediately after loading
    for old_col_name in df_excel.columns:
        new_col_name = clean_spark_column_name(old_col_name)
        if old_col_name != new_col_name:
            df_excel = df_excel.withColumnRenamed(old_col_name, new_col_name)

    # Path column (prefer _metadata.file_path when present; otherwise use input_file_name)
    # df_excel = df_excel.withColumn("full_file_path", F.input_file_name())
    df_excel = df_excel.withColumn("full_file_path", F.col("_metadata.file_path"))

    print(f"Successfully read CSV files")
    return df_excel


def get_staged_csv_data(file_path: str, csv_read_config: dict) -> pd.DataFrame:
    """
    Reads a CSV file from a local or mounted path into a pandas DataFrame,
    applying specific read configurations, and skips malformed lines.
    """
    print(f"  Reading staged CSV from: {file_path}")
    try:
        encoding = csv_read_config.get('encoding', 'utf-8')

        # Read file content using standard open()
        with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
            csv_content = f.read()

        csv_io = BytesIO(csv_content.encode(encoding))

        # First attempt
        df_raw = pd.read_csv(csv_io, **csv_read_config)
        df_raw["full_file_path"] = file_path

        print(f"  Successfully read CSV with {len(df_raw)} rows (bad lines skipped).")
        return df_raw

    except pd.errors.ParserError as e:
        print(f"⚠️ Parser error in '{file_path}': {e}")
        print("Retrying with python engine (slower but more tolerant)...")

        csv_io.seek(0)
        df_raw = pd.read_csv(csv_io, engine='python', **csv_read_config)
        df_raw["full_file_path"] = file_path
        print(f"  Successfully read CSV with {len(df_raw)} rows (after retry).")
        return df_raw

    except Exception as e:
        print(f"❌ Error reading staged CSV '{file_path}': {e}")
        raise

# ---------------------------------------------------------------------
# Transform
# ---------------------------------------------------------------------

def process_excel_to_golden_dataframe(
    spark, 
    df_excel: DataFrame,
    wholesaler_name: str,
    column_mapping: dict,
    golden_schema: dict
) -> DataFrame:
    
    print(f"Processing data for wholesaler: {wholesaler_name}")
    casted_cols = []

    # 1. CREATE CASE-INSENSITIVE LOOKUP MAP
    # Maps lowercase names to the actual case found in the DataFrame
    raw_column_map: Dict[str, str] = {col.lower(): col for col in df_excel.columns}

    for golden_col_name, golden_col_type in golden_schema.items():
        excel_col_mapping = column_mapping.get(golden_col_name)
        col_expr = None
        
        # --- Handle List of Possible Columns (Coalesce Logic) ---
        if isinstance(excel_col_mapping, list):
            existing_cols = []
            for c in excel_col_mapping:
                if isinstance(c, str) and c.lower() in raw_column_map:
                    existing_cols.append(F.col(raw_column_map[c.lower()]))
            
            if existing_cols:
                # Take the first non-null value among all provided column names
                col_expr = F.coalesce(*existing_cols)

        # --- Handle Single String Mapping ---
        elif isinstance(excel_col_mapping, str):
            if excel_col_mapping.lower() in raw_column_map:
                col_expr = F.col(raw_column_map[excel_col_mapping.lower()])

        # --- Handle Spark Column Expressions (F.lit, F.regexp_replace, etc.) ---
        elif isinstance(excel_col_mapping, Column):
            col_expr = excel_col_mapping

        # --- Apply Casting and Specific Cleanups ---
        if col_expr is not None:
            
            # Special logic for Double types (fixing comma decimals)
            if golden_col_type.upper() == "DOUBLE":
                # Ensure we are working with a string before replacing commas
                col_expr = F.regexp_replace(col_expr.cast("string"), r',', '.')
                casted_cols.append(col_expr.cast("DOUBLE").alias(golden_col_name))
            
            # Handle Date casting
            elif golden_col_type.upper() == "DATE":
                casted_cols.append(F.to_date(col_expr).alias(golden_col_name))
                
            # Handle Timestamp casting
            elif golden_col_type.upper() == "TIMESTAMP":
                casted_cols.append(F.to_timestamp(col_expr).alias(golden_col_name))
            
            # Standard cast for everything else
            else:
                casted_cols.append(col_expr.cast(golden_col_type).alias(golden_col_name))

        # --- Fallback: Column not found or Mapping is None ---
        else:
            casted_cols.append(F.lit(None).cast(golden_col_type).alias(golden_col_name))
            if excel_col_mapping is not None:
                print(f"⚠ None of the columns {excel_col_mapping} found for '{golden_col_name}'. Adding NULL.")
            else:
                print(f"⚠ No mapping provided for '{golden_col_name}'. Adding NULL.")

    df_golden = df_excel.select(*casted_cols)
    print(f"✅ Defined dynamic (coalesced) transformation for {wholesaler_name}.")
    
    return df_golden

def process_wholesaler_csv_files(
    spark: SparkSession,
    wholesaler_name: str,
    config: Mapping,
    base_volume_path: str,
    bronze_base_table_path: str,
    golden_template_schema: Optional[str] = None
) -> DataFrame:
    from collections import Counter
    
    # --- 1. Setup and Path Definition ---
    raw_folder_name = config["folder_name"]
    folder_name = re.sub(r'[^A-Za-z0-9]', '_', raw_folder_name)
    column_mapping = config["column_mapping"]
    csv_read_config = config.get("csv_read_config", {})
    
    folder_path = f"{base_volume_path}/{folder_name}"
    full_path_with_wildcard = f"{folder_path}/**/*.csv" 
    
    print(f"Defining read operation for path: {full_path_with_wildcard}")

    # --- 2. Read Operation ---
    if csv_read_config:
        df_raw_csv_spark = _read_with_pandas(spark, full_path_with_wildcard, csv_read_config, golden_template_schema)
    else:
        df_raw_csv_spark = _read_with_spark(spark, full_path_with_wildcard, golden_template_schema)

    if df_raw_csv_spark is None or (not df_raw_csv_spark.columns and df_raw_csv_spark.rdd.isEmpty()):
         return spark.createDataFrame([], golden_template_schema)

    # --- 3. THE FIX: Forcible Unique Renaming to kill [AMBIGUOUS_REFERENCE] ---
    # We rename everything to 'idx_0', 'idx_1' etc. so names can't conflict.
    original_raw_names = df_raw_csv_spark.columns
    temp_unique_names = [f"idx_{i}" for i in range(len(original_raw_names))]
    
    # Apply unique internal names
    df_raw_csv_spark = df_raw_csv_spark.toDF(*temp_unique_names)

    # Now we normalize the *original* names so we know which ones were supposed to be duplicates
    normalized_names = []
    for col_name in original_raw_names:
        new_name = col_name.lower().strip()
        new_name = re.sub(r'[\s\.\-\:]+', '_', new_name) 
        new_name = re.sub(r'_{2,}', '_', new_name)      
        new_name = new_name.strip('_')
        normalized_names.append(new_name)

    # Identify duplicates in the normalized list
    col_counts = Counter(normalized_names)
    duplicate_targets = [n for n, count in col_counts.items() if count > 1]

    final_selection = []
    handled_duplicates = set()

    for i, norm_name in enumerate(normalized_names):
        if norm_name in duplicate_targets:
            if norm_name not in handled_duplicates:
                # Find all temporary indices that belong to this normalized name
                indices = [j for j, n in enumerate(normalized_names) if n == norm_name]
                # Map them to our temporary 'idx_N' names
                temp_cols_to_merge = [F.col(f"idx_{j}") for j in indices]
                
                # Coalesce the temporary unique columns into one
                final_selection.append(F.coalesce(*temp_cols_to_merge).alias(norm_name))
                handled_duplicates.add(norm_name)
        else:
            # Not a duplicate, just rename it back from idx_N to the normalized name
            final_selection.append(F.col(f"idx_{i}").alias(norm_name))

    # Rebuild the DataFrame one last time
    df_raw_csv_spark = df_raw_csv_spark.select(*final_selection)
    
    print("Columns deduplicated and normalized successfully.")

    # --- 4. Conform to Golden Schema ---
    df_golden_template = process_excel_to_golden_dataframe(
        spark,
        df_raw_csv_spark,
        wholesaler_name,
        column_mapping,
        golden_template_schema
    )

    # --- 5. Filter and Return ---
    df_result = (
        df_golden_template
        .filter(F.col("customer_number").isNotNull())
        .filter(F.col("total_amount").isNotNull())
    )
    
    return df_result
# ---------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------
# def process_wholesaler_csv_files(
#     spark: SparkSession,
#     wholesaler_name: str,
#     config: Mapping,
#     base_volume_path: str,
#     bronze_base_table_path: str,
#     golden_template_schema: Optional[str] = None
# ) -> DataFrame:
    
#     # --- 1. Setup and Path Definition ---
#     raw_folder_name = config["folder_name"]
#     folder_name = re.sub(r'[^A-Za-z0-9]', '_', raw_folder_name)
#     column_mapping = config["column_mapping"]
    
#     # Get the CSV read config. This will be {} (empty dict) if not provided.
#     csv_read_config = config.get("csv_read_config", {})
    
#     # Define the wildcard path for the files, using recursive search (**)
#     # This allows it to find files in subdirectories (like date folders).
#     folder_path = f"{base_volume_path}/{folder_name}"
#     full_path_with_wildcard = f"{folder_path}/**/*.csv" 
    
#     print(f"Defining read operation for path: {full_path_with_wildcard}")

#     # --- 2. Conditional Read Operation (Spark vs. Pandas) ---

#     # 🔑 SWITCH: Use Pandas if 'csv_read_config' is present (not empty)
#     if csv_read_config:
#         print("Using Pandas (complex config) method to read files.")
#         # Uses _read_with_pandas to handle header: 20, etc., and converts to Spark DF
#         df_raw_csv_spark = _read_with_pandas(spark, full_path_with_wildcard, csv_read_config, golden_template_schema)
    
#     # 🔑 FALLBACK: Use Spark's native reader (simple config)
#     else:
#         print("Using Spark (native reader) method to read files.")
#         # Uses _read_with_spark which is faster and distributed
#         df_raw_csv_spark = _read_with_spark(spark, full_path_with_wildcard, golden_template_schema)

#     # Check for empty/failed read
#     if df_raw_csv_spark is None or (not df_raw_csv_spark.columns and df_raw_csv_spark.rdd.isEmpty()):
#          print("File reading failed or no files found. Returning empty DataFrame.")
#          return spark.createDataFrame([], golden_template_schema)

#     # --- 3. Column Cleanup and Conform to Golden Schema (Shared Logic) ---
    
#     # 🔑 CRITICAL FIX: LOWERCASE ALL COLUMN NAMES 🔑
#     # This ensures consistency for the column_mapping, regardless of how the file was read.
#     for col in df_raw_csv_spark.columns:
#         df_raw_csv_spark = df_raw_csv_spark.withColumnRenamed(
#             col, 
#             col.lower().replace('-', '_').replace(' ', '_').replace('.', '_').replace(':', '')
#         )
#     print("Column names converted to lowercase and snake_case for mapping consistency.")
#     df_raw_csv_spark.printSchema() # Uncomment for debugging

#     # Since all raw columns are now lowercase, the config should use lowercase column names.
#     # Note: process_excel_to_golden_dataframe needs to be defined elsewhere in your environment.
#     df_golden_template = process_excel_to_golden_dataframe(
#         spark,
#         df_raw_csv_spark,
#         wholesaler_name,
#         column_mapping,
#         golden_template_schema
#     )

#     # --- 4. Filter and Return (Lazy Transformations) ---
#     df_result = (
#         df_golden_template
#         .filter(F.col("customer_number").isNotNull())
#         .filter(F.col("total_amount").isNotNull())
#     )
    
#     return df_result

# --------------------------------------------------------------------------------------
# --- Helper Functions ---
# --------------------------------------------------------------------------------------

def _read_with_spark(spark: SparkSession, full_path_with_wildcard: str, golden_template_schema: Optional[str]) -> DataFrame:
    """Reads CSV files using native Spark reader and prints all discovered files."""
    try:
        # 1. Manually find and print files for debugging
        # We strip the wildcard to list the directory content
        base_dir = full_path_with_wildcard.replace("/**", "").replace("/*.csv", "")
        
        print(f"\n🔍 Spark checking for files in: {base_dir}")
        
        # Using dbutils if on Databricks, otherwise standard glob
        try:
            # Recursive search to match Spark's behavior
            import glob
            file_list = glob.glob(full_path_with_wildcard, recursive=True)
            file_list = [f for f in file_list if f.lower().endswith('.csv')]
            
            print(f"📂 Spark found {len(file_list)} CSV file(s) to union:")
            for idx, file_path in enumerate(file_list, 1):
                print(f"  {idx}. {file_path}")
            print("-" * 50)
        except Exception as list_e:
            print(f"⚠️ Could not print file list (but Spark will try to read): {list_e}")

        # 2. Configure the Spark Reader
        reader = spark.read.format("csv")
        
        spark_csv_options = {
            'header': 'true', 
            'inferSchema': 'false', 
            'sep': ',', 
            'encoding': 'UTF-8',
            'mergeSchema': 'true' # 💡 CRITICAL: Allows Spark to handle different columns in different files
        }
        
        for key, value in spark_csv_options.items():
            reader = reader.option(key, value)

        # 3. Load the data
        # F.input_file_name() is used here to preserve the path for each row
        df_raw_csv_spark = reader.load(full_path_with_wildcard).withColumn("full_file_path", F.input_file_name())
        
        return df_raw_csv_spark
        
    except Exception as e:
        print(f"❌ Error during native Spark file read: {e}")
        return spark.createDataFrame([], golden_template_schema)


def _read_with_pandas(spark: SparkSession, full_path_with_wildcard: str, csv_read_config: Mapping, golden_template_schema: Optional[str]) -> DataFrame:
    """Reads CSV files using os.walk for reliability and prints all found files."""
    
    # 1. Extract the base directory from the wildcard path
    # Removes the '/**/*.csv' part to get the root folder
    base_dir = full_path_with_wildcard.split('/**')[0]
    
    print(f"\n🔍 Searching for files in: {base_dir}")
    
    # 2. Find all CSV files using os.walk (more robust than glob on Volumes)
    file_list = []
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            if file.lower().endswith(".csv"):
                file_list.append(os.path.join(root, file))
    
    # --- PRINT ALL FOUND FILES ---
    total_files = len(file_list)
    print(f"📂 Found {total_files} CSV file(s):")
    for idx, file_path in enumerate(file_list, 1):
        print(f"  {idx}. {file_path}")
    print("-" * 50)
    # -----------------------------

    if not file_list:
        print("⚠️ No CSV files found. Returning empty DataFrame.")
        return spark.createDataFrame([], golden_template_schema)

    all_dfs_pandas = []
    pandas_header_index = csv_read_config.get("header", 1) - 1 

    pandas_options = {
        "header": pandas_header_index,
        "sep": csv_read_config.get("sep", ','),
        "encoding": csv_read_config.get("encoding", 'utf-8'),
        "skip_blank_lines": csv_read_config.get("skip_blank_lines", True),
        "on_bad_lines": csv_read_config.get("on_bad_lines", "skip"),
        "engine": 'python',
        # "dtype": str, # Keep as string for safe union
        # "low_memory": False 
    }
    
    for file_path in file_list:
        try:
            df_pandas = pd.read_csv(file_path, **pandas_options)
            
            if not df_pandas.empty:
                df_pandas['full_file_path'] = file_path 
                all_dfs_pandas.append(df_pandas)
                print(f"✅ Loaded: {os.path.basename(file_path)} ({len(df_pandas)} rows)")
            else:
                print(f"ℹ️ Skipped: {os.path.basename(file_path)} (File is empty)")
                
        except Exception as e:
            print(f"❌ Error reading {file_path}: {e}")
            
    if not all_dfs_pandas:
        return spark.createDataFrame([], golden_template_schema)

    # Combine all found DataFrames (Outer Join on columns)
    df_combined_pandas = pd.concat(all_dfs_pandas, ignore_index=True, sort=False)
    
    # Ensure NaNs are converted to None for Spark compatibility
    df_combined_pandas = df_combined_pandas.where(pd.notnull(df_combined_pandas), None)

    # Replace all types of nulls (NaN, NaT, etc.) with None
    df_combined_pandas = df_combined_pandas.replace({np.nan: None})
    
    print(f"🚀 Total rows combined: {len(df_combined_pandas)}")
    return spark.createDataFrame(df_combined_pandas)

##create spark schema from golden dict:

def create_spark_schema_from_dict(input_schema_dict: Dict[str, str]) -> StructType:
    """
    Converts a dictionary of column_name: data_type_string pairs into a 
    PySpark StructType schema, setting all fields as nullable=True.

    Args:
        input_schema_dict: A dictionary where keys are column names 
                           and values are the desired Spark data type strings 
                           (e.g., 'STRING', 'DOUBLE', 'DATE', 'TIMESTAMP').

    Returns:
        A PySpark StructType object representing the schema.
    """
    
    # --- Data Type Mapping Utility ---
    def _get_spark_type(type_str: str) -> Any:
        """Maps case-insensitive string representation to PySpark data type object."""
        type_str = type_str.upper().strip()
        
        # Simple/Common Types
        if type_str == 'STRING':
            return StringType()
        elif type_str == 'DOUBLE':
            return DoubleType()
        elif type_str in ('INT', 'INTEGER'):
            return IntegerType()
        elif type_str == 'DATE':
            return DateType()
        elif type_str == 'TIMESTAMP':
            return TimestampType()
        elif type_str == 'BOOLEAN':
            return BooleanType()
        
        # Decimal type with default precision/scale
        elif type_str.startswith('DECIMAL'):
            try:
                # Extracts precision and scale from strings like 'DECIMAL(10,2)'
                m = type_str.split('(')[1].split(')')[0].split(',')
                precision = int(m[0].strip())
                scale = int(m[1].strip())
                return DecimalType(precision, scale)
            except:
                # Default for simpler 'DECIMAL' or error in parsing
                return DecimalType(10, 2)
        
        # Default fallback
        else:
            print(f"⚠️ Warning: Unknown type '{type_str}'. Defaulting to StringType.")
            return StringType()

    # --- Schema Generation ---
    golden_schema = []

    for column_name, data_type_str in input_schema_dict.items():
        spark_type = _get_spark_type(data_type_str)
        # Assuming all fields should be nullable (True)
        golden_schema.append(StructField(column_name, spark_type, True))

    return StructType(golden_schema)
