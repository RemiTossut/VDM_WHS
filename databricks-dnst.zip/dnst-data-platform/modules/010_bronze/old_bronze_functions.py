# bronze_functions.py

from imports import *

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------
def clean_spark_column_name(col_name: str) -> str:
    cleaned_name = re.sub(r'[^\w\s]', ' ', col_name)
    cleaned_name = re.sub(r'\s+', '_', cleaned_name)
    cleaned_name = cleaned_name.strip(' _')
    cleaned_name = cleaned_name.lower()
    return cleaned_name

# ---------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------
def get_excel_data(spark, excel_path: str) -> DataFrame:
    """
    Reads CSV files from the given path into a Spark DataFrame, cleans column names,
    and adds a column for the source file path.
    """
    print(f"Reading CSV files from: {excel_path}")
    df_excel = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .option("delimiter", ",")
        .load(excel_path)
    )

    # Clean column names immediately after loading
    for old_col_name in df_excel.columns:
        new_col_name = clean_spark_column_name(old_col_name)
        if old_col_name != new_col_name:
            df_excel = df_excel.withColumnRenamed(old_col_name, new_col_name)

    # Path column (prefer _metadata.file_path when present; otherwise use input_file_name)
    # df_excel = df_excel.withColumn("full_file_path", F.input_file_name())
    df_excel = df_excel.withColumn("full_file_path", F.col("_metadata.file_path"))

    print(f"Successfully read CSV files")
    return df_excel


def get_staged_csv_data(file_path: str, csv_read_config: dict) -> pd.DataFrame:
    """
    Reads a CSV file from a local or mounted path into a pandas DataFrame,
    applying specific read configurations, and skips malformed lines.
    """
    print(f"  Reading staged CSV from: {file_path}")
    try:
        encoding = csv_read_config.get('encoding', 'utf-8')

        # Read file content using standard open()
        with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
            csv_content = f.read()

        csv_io = BytesIO(csv_content.encode(encoding))

        # First attempt
        df_raw = pd.read_csv(csv_io, **csv_read_config)
        df_raw["full_file_path"] = file_path

        print(f"  Successfully read CSV with {len(df_raw)} rows (bad lines skipped).")
        return df_raw

    except pd.errors.ParserError as e:
        print(f"⚠️ Parser error in '{file_path}': {e}")
        print("Retrying with python engine (slower but more tolerant)...")

        csv_io.seek(0)
        df_raw = pd.read_csv(csv_io, engine='python', **csv_read_config)
        df_raw["full_file_path"] = file_path
        print(f"  Successfully read CSV with {len(df_raw)} rows (after retry).")
        return df_raw

    except Exception as e:
        print(f"❌ Error reading staged CSV '{file_path}': {e}")
        raise

# ---------------------------------------------------------------------
# Transform
# ---------------------------------------------------------------------

def process_excel_to_golden_dataframe(
    spark, 
    df_excel: DataFrame,
    wholesaler_name: str,
    column_mapping: dict,
    golden_schema: dict
) -> DataFrame:
    
    print(f"Processing data for wholesaler: {wholesaler_name}")
    casted_cols = []

    # 1. CREATE CASE-INSENSITIVE LOOKUP MAP
    # Maps 'klantnummer' -> 'Klantnummer', 'totaal' -> 'Totaal', etc.
    raw_column_map: Dict[str, str] = {col.lower(): col for col in df_excel.columns}

    for golden_col_name, golden_col_type in golden_schema.items():
        # The value from the config (e.g., 'klantnummer' or 'totaal')
        excel_col_mapping = column_mapping.get(golden_col_name)
        
        # Determine the target column name (cased) in the raw DataFrame
        target_col_cased = None
        
        # --- Common Logic for Column Selection (Now Case-Insensitive) ---
        if isinstance(excel_col_mapping, list):
            # Case 1: list of possible columns (first present wins, check lowercase)
            for c in excel_col_mapping:
                if isinstance(c, str) and c.lower() in raw_column_map:
                    target_col_cased = raw_column_map[c.lower()]
                    break
        elif isinstance(excel_col_mapping, str):
            # Case 3: single column name (lookup using lowercase name)
            if excel_col_mapping.lower() in raw_column_map:
                target_col_cased = raw_column_map[excel_col_mapping.lower()]

        
        # --- Apply Mapping and Casting ---
        if target_col_cased:
            col_expr = F.col(target_col_cased)
            
            # **IMPORTANT: The logic to fix the comma-decimal issue remains essential**
            if golden_col_name == "total_amount" and golden_col_type.upper() == "DOUBLE":
                # Assumes the raw column is a string that needs cleanup (e.g., "Totaal")
                col_expr = F.regexp_replace(col_expr, r',', '.')
                casted_cols.append(col_expr.cast("DOUBLE").alias(golden_col_name))
                # print(f"✔ Using column '{target_col_cased}' (case-insensitive) for '{golden_col_name}', fixing decimal.")
            
            # Handle Date/Timestamp casting
            elif golden_col_type.upper() == "DATE":
                casted_cols.append(F.to_date(col_expr).alias(golden_col_name))
            elif golden_col_type.upper() == "TIMESTAMP":
                casted_cols.append(F.to_timestamp(col_expr).alias(golden_col_name))
            
            # Standard cast
            else:
                casted_cols.append(col_expr.cast(golden_col_type).alias(golden_col_name))

        # Case 2: Spark Column (e.g., F.lit(...) or expression) - does not require lookup
        elif isinstance(excel_col_mapping, Column):
            casted_cols.append(excel_col_mapping.cast(golden_col_type).alias(golden_col_name))
            print(f"✔ Applying literal/complex mapping for '{golden_col_name}'.")

        # Case 4: missing/invalid mapping
        else:
            casted_cols.append(F.lit(None).cast(golden_col_type).alias(golden_col_name))
            # Only print warning if a mapping was actually provided but failed
            if excel_col_mapping is not None:
                print(f"⚠ Column name '{excel_col_mapping}' not found (even case-insensitively) for '{golden_col_name}'. Adding NULL.")
            else:
                print(f"⚠ No mapping provided for '{golden_col_name}'. Adding NULL.")

    df_golden = df_excel.select(*casted_cols)
    print(f"✅ Defined lazy transformation for {wholesaler_name}.")
    
    return df_golden
# ---------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------
def process_wholesaler_csv_files(
    spark: SparkSession,
    wholesaler_name: str,
    config: Mapping,
    base_volume_path: str,
    bronze_base_table_path: str,
    golden_template_schema: Optional[str] = None
) -> DataFrame:
    
    # --- 1. Setup and Path Definition ---
    raw_folder_name = config["folder_name"]
    folder_name = re.sub(r'[^A-Za-z0-9]', '_', raw_folder_name)
    column_mapping = config["column_mapping"]
    
    # Get the CSV read config. This will be {} (empty dict) if not provided.
    csv_read_config = config.get("csv_read_config", {})
    
    # Define the wildcard path for the files, using recursive search (**)
    # This allows it to find files in subdirectories (like date folders).
    folder_path = f"{base_volume_path}/{folder_name}"
    full_path_with_wildcard = f"{folder_path}/**/*.csv" 
    
    print(f"Defining read operation for path: {full_path_with_wildcard}")

    # --- 2. Conditional Read Operation (Spark vs. Pandas) ---

    # 🔑 SWITCH: Use Pandas if 'csv_read_config' is present (not empty)
    if csv_read_config:
        print("Using Pandas (complex config) method to read files.")
        # Uses _read_with_pandas to handle header: 20, etc., and converts to Spark DF
        df_raw_csv_spark = _read_with_pandas(spark, full_path_with_wildcard, csv_read_config, golden_template_schema)
    
    # 🔑 FALLBACK: Use Spark's native reader (simple config)
    else:
        print("Using Spark (native reader) method to read files.")
        # Uses _read_with_spark which is faster and distributed
        df_raw_csv_spark = _read_with_spark(spark, full_path_with_wildcard, golden_template_schema)

    # Check for empty/failed read
    if df_raw_csv_spark is None or (not df_raw_csv_spark.columns and df_raw_csv_spark.rdd.isEmpty()):
         print("File reading failed or no files found. Returning empty DataFrame.")
         return spark.createDataFrame([], golden_template_schema)

    # --- 3. Column Cleanup and Conform to Golden Schema (Shared Logic) ---
    
    # 🔑 CRITICAL FIX: LOWERCASE ALL COLUMN NAMES 🔑
    # This ensures consistency for the column_mapping, regardless of how the file was read.
    for col in df_raw_csv_spark.columns:
        df_raw_csv_spark = df_raw_csv_spark.withColumnRenamed(
            col, 
            col.lower().replace('-', '_').replace(' ', '_').replace('.', '_').replace(':', '')
        )
    print("Column names converted to lowercase and snake_case for mapping consistency.")
    df_raw_csv_spark.printSchema() # Uncomment for debugging

    # Since all raw columns are now lowercase, the config should use lowercase column names.
    # Note: process_excel_to_golden_dataframe needs to be defined elsewhere in your environment.
    df_golden_template = process_excel_to_golden_dataframe(
        spark,
        df_raw_csv_spark,
        wholesaler_name,
        column_mapping,
        golden_template_schema
    )

    # --- 4. Filter and Return (Lazy Transformations) ---
    df_result = (
        df_golden_template
        .filter(F.col("customer_number").isNotNull())
        .filter(F.col("total_amount").isNotNull())
    )
    
    return df_result

# --------------------------------------------------------------------------------------
# --- Helper Functions ---
# --------------------------------------------------------------------------------------

def _read_with_spark(spark: SparkSession, full_path_with_wildcard: str, golden_template_schema: Optional[str]) -> DataFrame:
    """Reads CSV files using the native Spark reader (fallback/simple approach)."""
    try:
        reader = spark.read.format("csv")
        
        # Default Spark CSV options (Spark does not support 'header' as an integer index)
        spark_csv_options = {
            'header': 'true', 
            'inferSchema': 'false', 
            'sep': ',', 
            'encoding': 'UTF-8'
        }
        
        for key, value in spark_csv_options.items():
            reader = reader.option(key, value)

        # Spark handles the wildcard path and distributes the read
        df_raw_csv_spark = reader.load(full_path_with_wildcard).withColumn("full_file_path", F.input_file_name())
        return df_raw_csv_spark
        
    except Exception as e:
        print(f"Error during native Spark file read: {e}")
        return spark.createDataFrame([], golden_template_schema)


def _read_with_pandas(spark: SparkSession, full_path_with_wildcard: str, csv_read_config: Mapping, golden_template_schema: Optional[str]) -> DataFrame:
    """Reads CSV files using Pandas/glob and converts the result to a Spark DataFrame."""
    
    # 1. Find all files recursively (necessary because Pandas doesn't handle wildcards)
    file_list = glob.glob(full_path_with_wildcard, recursive=True)
    
    if not file_list:
        print("No CSV files found with glob in recursive path. Returning empty DataFrame.")
        return spark.createDataFrame([], golden_template_schema)

    all_dfs_pandas = []
    
    # Pandas 'header' argument takes the 0-based index. 
    # Adjusting for the config's 1-based index (e.g., 20 means index 19).
    pandas_header_index = csv_read_config.get("header", 1) - 1 

    pandas_options = {
        "header": pandas_header_index,
        "sep": csv_read_config.get("sep", ','),
        "encoding": csv_read_config.get("encoding", 'utf-8'),
        "skip_blank_lines": csv_read_config.get("skip_blank_lines", False),
        "on_bad_lines": csv_read_config.get("on_bad_lines", "error"),
        "engine": 'python' 
    }
    
    # 2. Loop and Read with Pandas
    for file_path in file_list:
        try:
            # Pass all options to pd.read_csv
            df_pandas = pd.read_csv(file_path, **pandas_options)
            df_pandas['full_file_path'] = file_path # Add path column
            all_dfs_pandas.append(df_pandas)
        except Exception as e:
            print(f"Error reading file {file_path} with Pandas: {e}")
            continue # Skip bad file
            
    if not all_dfs_pandas:
        return spark.createDataFrame([], golden_template_schema)

    # 3. Combine and Convert to Spark
    df_combined_pandas = pd.concat(all_dfs_pandas, ignore_index=True)
    
    # Convert the single, large Pandas DF into a distributed Spark DF
    df_raw_csv_spark = spark.createDataFrame(df_combined_pandas)
    
    return df_raw_csv_spark

##create spark schema from golden dict:

def create_spark_schema_from_dict(input_schema_dict: Dict[str, str]) -> StructType:
    """
    Converts a dictionary of column_name: data_type_string pairs into a 
    PySpark StructType schema, setting all fields as nullable=True.

    Args:
        input_schema_dict: A dictionary where keys are column names 
                           and values are the desired Spark data type strings 
                           (e.g., 'STRING', 'DOUBLE', 'DATE', 'TIMESTAMP').

    Returns:
        A PySpark StructType object representing the schema.
    """
    
    # --- Data Type Mapping Utility ---
    def _get_spark_type(type_str: str) -> Any:
        """Maps case-insensitive string representation to PySpark data type object."""
        type_str = type_str.upper().strip()
        
        # Simple/Common Types
        if type_str == 'STRING':
            return StringType()
        elif type_str == 'DOUBLE':
            return DoubleType()
        elif type_str in ('INT', 'INTEGER'):
            return IntegerType()
        elif type_str == 'DATE':
            return DateType()
        elif type_str == 'TIMESTAMP':
            return TimestampType()
        elif type_str == 'BOOLEAN':
            return BooleanType()
        
        # Decimal type with default precision/scale
        elif type_str.startswith('DECIMAL'):
            try:
                # Extracts precision and scale from strings like 'DECIMAL(10,2)'
                m = type_str.split('(')[1].split(')')[0].split(',')
                precision = int(m[0].strip())
                scale = int(m[1].strip())
                return DecimalType(precision, scale)
            except:
                # Default for simpler 'DECIMAL' or error in parsing
                return DecimalType(10, 2)
        
        # Default fallback
        else:
            print(f"⚠️ Warning: Unknown type '{type_str}'. Defaulting to StringType.")
            return StringType()

    # --- Schema Generation ---
    golden_schema = []

    for column_name, data_type_str in input_schema_dict.items():
        spark_type = _get_spark_type(data_type_str)
        # Assuming all fields should be nullable (True)
        golden_schema.append(StructField(column_name, spark_type, True))

    return StructType(golden_schema)
