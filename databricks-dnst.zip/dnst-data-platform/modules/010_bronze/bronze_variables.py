golden_template_schema = {
    "wholesaler_id": "STRING",
    "customer_address": "STRING",
    "customer_city": "STRING",
    "customer_postal_code": "STRING",
    "customer_country": "STRING",
    "customer_name": "STRING",
    "customer_number": "STRING",
    "product_number": "STRING",
    "article_name": "STRING",
    "EAN": "STRING",         
    "total_amount": "DOUBLE",
    "UOM": "STRING",
    "wholesaler_name": "STRING",
    "vat_number": "STRING",
    "date": "STRING",
    "full_file_path": "STRING",
    "owner_name": "STRING"
}