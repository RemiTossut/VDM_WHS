# Databricks notebook source
# # Parameter
# project_folder = "dnst-data-platform"

# import sys
# import os
# # get modules dir
# cwd = os.getcwd()
# root_dir = cwd[:cwd.index(project_folder)+len(project_folder)]
# modules_dir = os.path.join(root_dir, "modules")
# # Add modules dir to python path
# if modules_dir not in sys.path:
#     # Add the folder to the path
#     print(f"Added {modules_dir} to the python path")
#     sys.path.append(modules_dir)

# COMMAND ----------

# Parameter
project_folder = "dnst-data-platform"

import sys
import os

# Get root directory based on project folder
cwd = os.getcwd()
root_dir = cwd[:cwd.index(project_folder) + len(project_folder)]
modules_dir = os.path.join(root_dir, "modules")

# Recursively add all subdirectories under modules to sys.path
for dirpath, dirnames, filenames in os.walk(modules_dir):
    if dirpath not in sys.path:
        sys.path.append(dirpath)
        print(f"Added {dirpath} to the Python path")
