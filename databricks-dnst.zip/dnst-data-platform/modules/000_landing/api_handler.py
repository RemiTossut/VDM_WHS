import requests
import datetime


def log_request(func):
    def wrapper(*args, **kwargs):
        # parameters
        url = None
        payload = None
        status_code= -1
        request_time = datetime.datetime.utcnow()
        request_duration = None
        error = None
        # try to do the request  
        try:
            response = func(*args, **kwargs)
            url = response.url
            payload = response.text
            status_code = response.status_code
            request_duration = response.elapsed.total_seconds()
            response.raise_for_status()
        except Exception as e:
            error=str(e)
        # return all information
        response_dict =  {
            "url": url, 
            "payload": payload, 
            "status_code": status_code,  
            "request_time": request_time,
            "request_duration": request_duration,
            "error": error
            }
        return response_dict
    return wrapper


@log_request
def get_request(**kwargs):
    return requests.get(**kwargs)


@log_request
def post_request(**kwargs):
    return requests.post(**kwargs)