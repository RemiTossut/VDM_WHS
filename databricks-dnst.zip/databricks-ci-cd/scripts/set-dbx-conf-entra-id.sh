#!/bin/bash

WORKSPACE_URL=''
CLIENT_ID=''
CLIENT_SECRET=''
PROFILE_NAME=''
TENANT_ID=''


while getopts "w:i:s:p:t:" options; do
    case "${options}" in
        w)
            WORKSPACE_URL=${OPTARG}
            ;;
        i)
            CLIENT_ID=${OPTARG}
            ;;
        s)
            CLIENT_SECRET=${OPTARG}
            ;;
        p) 
            PROFILE_NAME=${OPTARG}
            ;;
        t) 
            TENANT_ID=${OPTARG}
            ;;
        :)
            echo "Error: ${OPTARG} requires an argument."
            exit 1
            ;;
        *)
            echo "Got unexpected argument: ${options}"
            exit 1
            ;;
    esac
done

if [[ "${WORKSPACE_URL}" = '' ]]; then
    echo "Error: Expects a workspace url to be passes using the -w flag!"
    exit 1
fi
if [[ "${CLIENT_ID}" = '' ]]; then
    echo "Error: Expects a client id to be passes using the -i flag!"
    exit 1
fi
if [[ "${CLIENT_SECRET}" = '' ]]; then
    echo "Error: Expects a client secret to be passes using the -s flag!"
    exit 1
fi
if [[ "${TENANT_ID}" = '' ]]; then
    echo "Error: Expects a tenant id to be passes using the -t flag!"
    exit 1
fi
if [[ "${PROFILE_NAME}" = '' ]]; then
    echo "No profile was passed through the -p flag. Defaulting to 'DEFAULT'"
    PROFILE_NAME='DEFAULT';
fi


echo $'['${PROFILE_NAME}$']\nhost = '${WORKSPACE_URL}$'\nazure_client_id = '${CLIENT_ID}$'\nazure_client_secret = '${CLIENT_SECRET}$'\nazure_tenant_id = '${TENANT_ID}$'\n\n' > ~/.databrickscfg

exit 0