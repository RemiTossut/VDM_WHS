param (
    [string]$WORKSPACE_URL,
    [string]$CLIENT_ID,
    [string]$CLIENT_SECRET,
    [string]$PROFILE_NAME = "DEFAULT",
    [string]$TENANT_ID
)

# Validate required parameters
if (-not $WORKSPACE_URL -or -not $CLIENT_ID -or -not $CLIENT_SECRET -or -not $TENANT_ID) {
    Write-Host "Error: Missing required parameters!"
    exit 1
}

# Create and write the databrickscfg content
@"
[$PROFILE_NAME]
host = $WORKSPACE_URL
azure_client_id = $CLIENT_ID
azure_client_secret = $CLIENT_SECRET
azure_tenant_id = $TENANT_ID
"@ | Out-File -FilePath "$HOME/.databrickscfg" -Encoding utf8

Write-Host "Configuration written to $HOME/.databrickscfg"
exit 0
